"""命令行入口：`python -m manhua_agent.cli ...`"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import List

from .config import PipelineConfig
from .graph import run_pipeline


def _parse_keywords(args: argparse.Namespace) -> List[str]:
    if args.keywords:
        return [k.strip() for k in args.keywords.split(",") if k.strip()]
    if args.input:
        p = Path(args.input)
        if p.suffix.lower() == ".json":
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return [str(k) for k in data]
            if isinstance(data, dict):
                return [str(k) for k in data.get("keywords", [])]
    return []


def _read_novel(path: str) -> str:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"novel 输入文件不存在：{path}")
    return p.read_text(encoding="utf-8")


def _build_config(args: argparse.Namespace) -> PipelineConfig:
    if args.mode == "novel":
        if not args.input:
            raise SystemExit("novel 模式必须提供 --input <小说 .txt 文件>")
        novel_text = _read_novel(args.input)
        return PipelineConfig(
            mode="novel",
            novel_text=novel_text,
            title=args.title,
            branch_count=args.branches,
            staging=args.staging,
            dry_run=args.dry_run,
            verbose=args.verbose,
        )
    # keywords
    kw = _parse_keywords(args)
    theme = None
    if args.input and Path(args.input).suffix.lower() == ".json":
        data = json.loads(Path(args.input).read_text(encoding="utf-8"))
        if isinstance(data, dict):
            theme = data.get("theme")
    return PipelineConfig(
        mode="keywords",
        keywords=kw,
        theme=theme,
        title=args.title,
        branch_count=args.branches,
        staging=args.staging,
        dry_run=args.dry_run,
        verbose=args.verbose,
    )


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="manhua_agent",
        description="互动漫剧游戏生成智能体 —— 一键把小说/关键词生成为可玩互动漫剧 JSON",
    )
    parser.add_argument(
        "--mode", required=True, choices=["novel", "keywords"], help="输入模式"
    )
    parser.add_argument("--input", help="输入文件路径（novel: .txt；keywords: .json）")
    parser.add_argument("--keywords", help="关键词（逗号分隔），仅 keywords 模式")
    parser.add_argument("--title", help="作品标题（可选，未指定则由 AI 自拟）")
    parser.add_argument("--branches", type=int, default=3, help="主分支数量（默认 3）")
    parser.add_argument(
        "--staging",
        choices=["static", "semi-dynamic", "full-video"],
        default="semi-dynamic",
        help="演出档位（默认 semi-dynamic）",
    )
    parser.add_argument("--output", default="output/game.json", help="输出 JSON 路径")
    parser.add_argument(
        "--dry-run", action="store_true", help="不调用 LLM，用规则占位生成器跑通链路"
    )
    parser.add_argument("--verbose", action="store_true", help="打印每个 Agent 的中间产物")
    parser.add_argument(
        "--dump-full",
        action="store_true",
        help="除 GameOutput 外，另存一份包含所有中间产物的 full.json",
    )

    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(name)s %(levelname)s | %(message)s",
    )

    config = _build_config(args)
    result = run_pipeline(config)

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        result.game.model_dump_json(indent=2),
        encoding="utf-8",
    )
    print(f"✔ 已生成互动漫剧游戏 JSON: {out_path}")
    print(f"  - Schema 版本: {result.game.schema_version}")
    print(f"  - 节点数: {len(result.game.story_tree.nodes)}")
    print(f"  - 结局数: {len(result.game.story_tree.endings)}")
    print(f"  - 起始节点: {result.game.story_tree.start_node}")
    print(f"  - 道具数量: {len(result.game.assets.items)}")
    print(f"  - 场景数量: {len(result.game.assets.scenes)}")
    print(f"  - BGM/CG/Voiceover: {len(result.game.assets.bgms)}/"
          f"{len(result.game.assets.cgs)}/{len(result.game.assets.voiceovers)}")
    if result.game.acts:
        print(f"  - 幕/章: {len(result.game.acts)}/"
              f"{len(result.game.chapters) if result.game.chapters else 0}")
    print(f"  - 一致性检查: passed={result.consistency.passed}")
    if result.consistency.duplicate_branch_pairs:
        print(f"    ! 检测到疑似雷同分支对: {result.consistency.duplicate_branch_pairs}")
    if result.consistency.dangling_item_refs:
        print(f"    ! 悬空道具引用: {result.consistency.dangling_item_refs}")
    if result.consistency.condition_var_issues:
        print(f"    ! Condition 引用问题: {result.consistency.condition_var_issues}")

    if args.dump_full:
        full_path = out_path.with_name(out_path.stem + "_full.json")
        full_path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        print(f"✔ 完整过程产物写入: {full_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
