/* ============================================================
 * 互动漫剧生成器 · 本地向导前端逻辑
 * ============================================================ */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  const state = {
    mode: "keywords",
    jobId: null,
    poll: null,
    skeleton: null,
    game: null,
    player: null,
    config: null,
  };

  // ---------------- 通用 ---------------- //
  function toast(msg, isErr) {
    const t = $("#gToast");
    t.textContent = msg;
    t.className = "toast-global show" + (isErr ? " err" : "");
    setTimeout(() => (t.className = "toast-global"), 2600);
  }

  async function api(path, opts) {
    const res = await fetch(path, opts);
    if (!res.ok) {
      let detail = res.statusText;
      try { detail = (await res.json()).detail || detail; } catch (e) {}
      throw new Error(detail);
    }
    return res.json();
  }

  function gotoStep(n) {
    for (let i = 1; i <= 5; i++) {
      const p = $("#panel" + i);
      if (p) p.style.display = i === n ? "" : "none";
    }
    $$("#stepbar .step").forEach((el) => {
      const s = +el.dataset.step;
      el.classList.toggle("active", s === n);
      el.classList.toggle("done", s < n);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // ---------------- 初始化：读配置 ---------------- //
  async function loadConfig() {
    try {
      const cfg = await api("/api/config");
      state.config = cfg;
      $("#videoRatio").value = cfg.video_ratio;
      $("#ratioVal").textContent = (+cfg.video_ratio).toFixed(2);
      $("#dryRun").checked = !cfg.llm_ready; // 无 LLM 时默认 dry-run
      const badges = [
        ["LLM", cfg.llm_ready],
        ["图片API", cfg.image_api_ready],
        ["视频API", cfg.video_api_ready],
      ]
        .map(([n, on]) => `<span class="badge ${on ? "on" : "off"}">${on ? "●" : "○"} ${n}</span>`)
        .join("");
      $("#envBadges").innerHTML = badges;
    } catch (e) {
      $("#envBadges").innerHTML = '<span class="badge off">配置读取失败</span>';
    }
  }

  // ---------------- 步骤1：输入 ---------------- //
  $$("#modeSeg .seg").forEach((btn) => {
    btn.onclick = () => {
      $$("#modeSeg .seg").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.mode = btn.dataset.mode;
      $("#kwBlock").style.display = state.mode === "keywords" ? "" : "none";
      $("#novelBlock").style.display = state.mode === "novel" ? "" : "none";
    };
  });

  $("#novelFile").onchange = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => ($("#novelText").value = reader.result);
    reader.readAsText(f, "utf-8");
  };

  $("#toStep2").onclick = () => {
    if (state.mode === "keywords" && !$("#keywords").value.trim()) {
      return toast("请填写至少一个关键词", true);
    }
    if (state.mode === "novel" && !$("#novelText").value.trim()) {
      return toast("请粘贴或上传小说正文", true);
    }
    gotoStep(2);
  };

  // ---------------- 步骤2：参数 ---------------- //
  $("#branchCount").oninput = (e) => ($("#branchVal").textContent = e.target.value);
  $("#maxNodes").oninput = (e) => ($("#nodesVal").textContent = e.target.value);
  $("#videoRatio").oninput = (e) => ($("#ratioVal").textContent = (+e.target.value).toFixed(2));
  $("#backTo1").onclick = () => gotoStep(1);

  $("#startRun").onclick = async () => {
    const body = {
      mode: state.mode,
      keywords: $("#keywords").value.split(/[,，]/).map((s) => s.trim()).filter(Boolean),
      novel_text: state.mode === "novel" ? $("#novelText").value : null,
      theme: $("#theme").value.trim() || null,
      title: $("#title").value.trim() || null,
      branch_count: +$("#branchCount").value,
      staging: $("#staging").value,
      max_nodes_per_branch: +$("#maxNodes").value,
      video_ratio: +$("#videoRatio").value,
      dry_run: $("#dryRun").checked,
    };
    try {
      const r = await api("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      state.jobId = r.job_id;
      gotoStep(3);
      renderAgents(null);
      startPolling();
    } catch (e) {
      toast("创建任务失败：" + e.message, true);
    }
  };

  // ---------------- 步骤3：进度轮询 ---------------- //
  const AGENT_ICONS = {
    parser: "📖", planner: "🗺️", writer: "✍️", consistency: "🔍",
    gamification: "🎮", direction: "🎬", structurer: "🧩",
  };

  function renderAgents(steps) {
    const ul = $("#agentList");
    if (!steps) { ul.innerHTML = ""; return; }
    ul.innerHTML = steps.map((s) => {
      const st = s.status;
      const ico = st === "done" ? "✓" : st === "error" ? "!" : (AGENT_ICONS[s.key] || "•");
      return `<li class="agent ${st}">
        <div class="ico">${ico}</div>
        <div class="body">
          <div class="name">${s.label}</div>
          <div class="msg">${s.message || s.desc || ""}</div>
        </div>
      </li>`;
    }).join("");
  }

  function startPolling() {
    if (state.poll) clearInterval(state.poll);
    state.poll = setInterval(pollStatus, 1000);
    pollStatus();
  }

  async function pollStatus() {
    if (!state.jobId) return;
    let s;
    try { s = await api(`/api/jobs/${state.jobId}/status`); }
    catch (e) { return; }

    renderAgents(s.steps);
    $("#runStatusLine").textContent = statusLabel(s.status);

    // 素材进度
    if (s.status === "generating_assets" || (s.asset_progress && s.asset_progress.total)) {
      const ap = s.asset_progress || { done: 0, total: 0 };
      $("#assetBar").style.display = ap.total ? "" : "none";
      if (ap.total) {
        $("#assetFill").style.width = (ap.done / ap.total) * 100 + "%";
        $("#assetMsg").textContent = ap.message || "";
      }
    }

    if (s.status === "error") {
      clearInterval(state.poll);
      toast("生成失败：" + (s.error || "未知错误"), true);
      $("#runStatusLine").textContent = "❌ " + (s.error || "生成失败");
      return;
    }

    if (s.status === "awaiting_confirm") {
      clearInterval(state.poll);
      await loadSkeleton();
      gotoStep(4);
      return;
    }

    if (s.status === "finished") {
      clearInterval(state.poll);
      state.lastStatus = s;
      await showPreview(s);
    }
  }

  function statusLabel(st) {
    return ({
      created: "已创建，准备启动……",
      running_plan: "正在运行 解析 → 规划 Agent……",
      awaiting_confirm: "等待人工确认剧情分支……",
      running_after: "正在运行 写作 → 一致性 → 游戏化 → 演出 → 结构化……",
      generating_assets: "正在生成动静混合素材……",
      finished: "✅ 生成完成！",
      error: "❌ 出错了",
    })[st] || st;
  }

  // ---------------- 步骤4：HITL 分支编辑 ---------------- //
  async function loadSkeleton() {
    const sk = await api(`/api/jobs/${state.jobId}/skeleton`);
    state.skeleton = sk;
    // 变量
    $("#varsView").innerHTML = Object.entries(sk.variables || {})
      .map(([k, v]) => `<span class="chip">${esc(k)} <b>${v}</b></span>`)
      .join("") || '<span class="muted">（无）</span>';
    // 分支
    const editor = $("#branchEditor");
    editor.innerHTML = (sk.branches || []).map((b, i) => branchCard(b, i)).join("");
  }

  function branchCard(b, i) {
    const beats = (b.beats || []).map((bt, j) =>
      `<input type="text" data-branch="${i}" data-beat="${j}" value="${esc(bt)}" />`
    ).join("");
    return `<div class="branch-card">
      <div class="bhead">
        <span class="bid">${esc(b.id || "b" + i)}</span>
        <input type="text" data-branch="${i}" data-field="label" value="${esc(b.label || "")}" placeholder="分支名称" />
      </div>
      <label>核心冲突来源</label>
      <input type="text" data-branch="${i}" data-field="conflict_source" value="${esc(b.conflict_source || "")}" />
      <label>结局走向</label>
      <input type="text" data-branch="${i}" data-field="ending_direction" value="${esc(b.ending_direction || "")}" />
      <label>剧情节拍（每行一个，可编辑）</label>
      <div class="beats-list">${beats || '<span class="muted">（无节拍）</span>'}</div>
    </div>`;
  }

  function collectSkeleton() {
    const sk = JSON.parse(JSON.stringify(state.skeleton));
    $$("#branchEditor [data-branch]").forEach((el) => {
      const bi = +el.dataset.branch;
      if (!sk.branches[bi]) return;
      if (el.dataset.field) {
        sk.branches[bi][el.dataset.field] = el.value;
      } else if (el.dataset.beat !== undefined) {
        sk.branches[bi].beats[+el.dataset.beat] = el.value;
      }
    });
    return sk;
  }

  $("#reloadSkeleton").onclick = () => loadSkeleton();

  $("#confirmContinue").onclick = async () => {
    $("#confirmContinue").disabled = true;
    try {
      const sk = collectSkeleton();
      await api(`/api/jobs/${state.jobId}/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skeleton: sk }),
      });
      gotoStep(3);
      startPolling();
    } catch (e) {
      toast("确认失败：" + e.message, true);
    } finally {
      $("#confirmContinue").disabled = false;
    }
  };

  // ---------------- 步骤5：预览 & 导出 ---------------- //
  async function showPreview(status) {
    const game = await api(`/api/jobs/${state.jobId}/game`);
    state.game = game;
    gotoStep(5);
    // 挂载播放器，素材从后端静态服务读取
    state.player = window.ManhuaPlayer.mount($("#playerHost"), game, {
      assetBase: `/api/jobs/${state.jobId}/`,
    });
    renderStats(game, status);
  }

  function renderStats(game, status) {
    const st = game.story_tree;
    const counts = {};
    st.nodes.forEach((n) => (counts[n.media_type || "none"] = (counts[n.media_type || "none"] || 0) + 1));
    $("#gameStats").innerHTML = `
      <h4>📊 作品信息</h4>
      <div class="kv"><span>标题</span><b>${esc(game.title)}</b></div>
      <div class="kv"><span>节点数</span><b>${st.nodes.length}</b></div>
      <div class="kv"><span>结局数</span><b>${(st.endings || []).length}</b></div>
      <div class="kv"><span>道具数</span><b>${((game.assets && game.assets.items) || []).length}</b></div>
      <div class="kv"><span>起始节点</span><b>${esc(st.start_node)}</b></div>`;

    const ar = status && status.asset_result;
    const line = ar
      ? (ar.enabled
          ? `已生成 图片 ${ar.generated.image} / 视频 ${ar.generated.video}`
          : `未配置素材 API，已跳过生成（用占位底图）`)
      : "";
    $("#assetStats").innerHTML = `
      <h4>🎨 动静混合</h4>
      <div class="kv"><span>动态比例 video_ratio</span><b>${ar ? ar.video_ratio : "-"}</b></div>
      <div class="kv"><span>规划：静态图</span><b>${counts.image || 0}</b></div>
      <div class="kv"><span>规划：视频</span><b>${counts.video || 0}</b></div>
      <div class="kv"><span>素材状态</span><b>${esc(line)}</b></div>`;
  }

  $("#exportBtn").onclick = async () => {
    $("#exportBtn").disabled = true;
    $("#exportInfo").innerHTML = "打包中……";
    try {
      const r = await api(`/api/jobs/${state.jobId}/export`, { method: "POST" });
      const dl = $("#downloadBtn");
      dl.href = `/api/jobs/${state.jobId}/download`;
      dl.style.display = "";
      const sizeCls = r.oversize ? "warn" : "ok";
      $("#exportInfo").innerHTML = `
        <div class="${sizeCls}">${r.oversize ? "⚠ 超出 8MB 限制" : "✓ 符合抖音互动空间要求（≤8MB，根目录含 index.html）"}</div>
        包体大小：<b>${r.size_mb} MB</b> · 文件 ${r.file_count} 个 · 素材 ${r.asset_count} 个<br/>
        下载后解压双击 <code>index.html</code> 即可本地游玩。`;
      toast("导出成功！");
    } catch (e) {
      $("#exportInfo").innerHTML = `<span class="warn">导出失败：${esc(e.message)}</span>`;
      toast("导出失败：" + e.message, true);
    } finally {
      $("#exportBtn").disabled = false;
    }
  };

  $("#restartAll").onclick = () => location.reload();

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // ---------------- 启动 ---------------- //
  loadConfig();
  gotoStep(1);
})();
