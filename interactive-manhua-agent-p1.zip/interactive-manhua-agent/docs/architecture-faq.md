# 架构选型 FAQ：为什么选 LangGraph，不选 LangChain / AIME / Coze

> 这份文档是给产品经理做知识储备用的，不追求框架百科式介绍，而是围绕当前互动漫剧 Agent 项目解释：为什么 P0 先用 LangGraph 编排 7 个 Agent 串行流水线，模型调用先用 `openai` 库做 OpenAI-Compatible 接入，而不是直接上 LangChain AgentExecutor、AIME 或 Coze。

---

## 0. 先说结论

当前项目的核心不是“让一个 Agent 自己到处想办法完成任务”，而是“把小说 / 关键词稳定加工成一份可运行的互动漫剧游戏 JSON”。

所以我们真正需要的是一条可控流水线：

```text
Parser → Planner → Writer → Consistency → Gamification → Direction → Structurer
```

每一步职责清楚，输入输出清楚，中间产物可以检查，失败后知道该从哪一步重跑。

从这个目标看，LangGraph 比 LangChain AgentExecutor 更合适；自研代码 + LangGraph 也比直接套 AIME / Coze 的 skill + agent runtime + llm 结构更合适。AIME / Coze 更像“搭一个可运营的通用 Agent 产品平台”，而我们 P0 更像“做一条业务生成流水线的技术原型”。

---

## 1. LangGraph / LangChain / AIME·Coze 分别是什么？

### 1.1 LangGraph：更像“Agent 流程编排器”

LangGraph 可以理解成一个专门编排多步骤 AI 流程的框架。

它的重点不是帮你写很多现成能力，而是让你把流程画成一张图：有哪些节点、节点之间怎么流转、什么情况下回退、状态怎么传下去。

在当前项目里，它对应的是 `src/manhua_agent/graph.py` 里的这条链路：

```text
parse → plan → write → check → gamify → direct → structure
```

这里每个节点就是一个明确的业务 Agent：解析、规划、写作、一致性检查、游戏化、演出设计、结构化输出。

它适合我们，是因为互动漫剧生成不是一次聊天，而是一个“生产流程”。像工厂流水线一样，每个工位做自己的事，最后组装成可运行 JSON。

### 1.2 LangChain：更像“LLM 应用工具箱”

LangChain 更大、更全，里面有模型封装、Prompt 模板、记忆、工具调用、RAG、AgentExecutor 等很多模块。

它适合快速做一个“会调用工具的 Agent”，比如用户问问题，Agent 判断要不要查资料、要不要调工具、要不要继续追问。

但对我们这个项目来说，LangChain 的通用 Agent 能力不是最核心的。我们不是要让模型自由决定下一步，而是希望流程严格按产品设计走：先理解原文，再规划剧情树，再写节点，再校验，再游戏化，再设计演出，最后强制结构化。

### 1.3 AIME / Coze：更像“Agent 产品平台”

AIME 和 Coze 更接近 Agent 应用平台。它们通常会把能力拆成几类：skill、agent runtime、llm、工具、知识库、触发器、工作流、发布和运营能力。

它们的优势是产品化程度高：适合快速搭出一个能被用户使用、能配置技能、能接工具、能上线运营的 Agent。

但这类平台也会带来一层运行时抽象。对 P0 技术原型来说，这层抽象反而可能让我们更难精细控制每一步的状态、Schema、自修复逻辑和调试链路。

---

## 2. 为什么选 LangGraph，不选 LangChain AgentExecutor？

### 2.1 因为我们要的是“确定流程”，不是“自由 Agent”

LangChain AgentExecutor 的典型思路是：给 Agent 一组工具，让它自己判断下一步调用什么。

这个模式适合开放式任务，比如“帮我查资料并总结”“帮我排查问题”“帮我订一个行程”。因为这些任务路径不固定，Agent 自己决策会比较灵活。

但互动漫剧生成的路径很固定：

```text
输入小说/关键词
→ 抽取设定
→ 规划剧情树
→ 写节点
→ 查一致性
→ 加选择和小游戏
→ 标注演出
→ 输出 JSON
```

如果让 AgentExecutor 自由决定顺序，它可能跳过某些步骤，也可能反复调用不必要的工具，还可能在中间产物没准备好的时候进入下一步。对 P0 来说，这种灵活性不是优势，而是风险。

### 2.2 因为当前项目强依赖“中间状态”

当前项目里，每一步都有明确的中间产物：

Parser 产出 `StorySetting`，Planner 产出 `StorySkeleton`，Writer 产出 `Node` 列表，Consistency 产出校验报告，Gamification 给节点挂选择、小游戏、道具和结局，Direction 补场景、BGM、CG、Voiceover，Structurer 最后汇总成 `GameOutput`。

这些产物不是聊天记录，而是结构化对象。它们要一路传下去，还要被后续步骤读取和修改。

LangGraph 的 StateGraph 很适合做这件事：状态是什么、每个节点读什么写什么、什么时候进入下一节点，都可以明确写在代码里。

AgentExecutor 更偏“Agent 思考 + 工具调用”的运行循环，不天然强调这种稳定的业务状态机。

### 2.3 因为我们需要“可控回退”，不是泛泛重试

项目里有一个很典型的逻辑：Consistency 如果发现支线雷同或人设冲突，可以回到 Writer 重写；超过最大重试次数后，才带着问题记录继续往后走。

这不是简单的 API retry，而是业务流程上的条件回边：

```text
write → check
        ├─ 通过 → gamify
        └─ 不通过且未超限 → write
```

LangGraph 对这种图结构很自然。我们可以把“检查失败后回到哪一步”写成图上的边。

如果用 AgentExecutor，就需要把这类流程控制藏在 Agent 的 prompt 或工具逻辑里。短期能跑，但出了问题很难判断：到底是 prompt 没写清楚，还是 Agent 自己选错了步骤，还是某个工具返回不对。

### 2.4 因为产品经理需要能看懂链路

这个项目后续一定会讨论很多产品问题：为什么分支雷同，为什么小游戏插得不合适，为什么演出档位不符合预期，为什么 JSON 跑不起来。

如果流程是 LangGraph 这种显式流水线，产品经理也能顺着链路定位：

是 Parser 没理解原文，还是 Planner 支线拆得不好，还是 Writer 写得重复，还是 Consistency 没拦住，还是 Gamification 规则太粗。

如果流程是一个大 Agent 自己调工具，定位问题会更像“黑盒复盘”：它当时为什么这么想，为什么没调用某个工具，很难稳定复现。

---

## 3. 为什么选 LangGraph，不选 AIME / Coze 的 skill + agent runtime + llm 结构？

### 3.1 AIME / Coze 更适合“产品化 Agent”，LangGraph 更适合“工程化流水线”

AIME / Coze 的优势是把 Agent 产品化。你可以配置 skill，接工具，接知识库，接工作流，然后比较快地交付一个可用 Agent。

但当前项目的 P0 目标不是先搭一个平台型 Agent，而是验证一条核心生成链路：输入小说或关键词，能不能稳定产出一份符合 Schema 的互动漫剧游戏 JSON。

这个阶段最重要的是：流程透明、代码可控、数据结构可控、失败可定位。

LangGraph + Python 代码更贴近这个目标。

### 3.2 当前项目不是“多个 skill 被 Agent 动态调用”，而是“多个业务工序固定串联”

AIME / Coze 的 skill 模式通常是：Agent 遇到某类需求时，选择调用某个 skill。

但我们现在的 7 个 Agent 不是“可选技能”，而是“必经工序”。Parser、Planner、Writer、Consistency、Gamification、Direction、Structurer 不是让模型自由挑的工具，而是一条产品定义好的生产线。

例如，不能让模型觉得“今天不用一致性校验”；也不能让它先做演出设计，再回头补剧情树。顺序本身就是业务逻辑。

所以用 LangGraph 显式固化流程，比把这些工序包装成 skill 后交给 runtime 调度更稳。

### 3.3 当前项目对 Schema 和自修复要求很强

互动漫剧 Agent 的最终产物不是一段文案，而是可运行 JSON。它要包含剧情树、节点、变量、条件、道具、小游戏、演出资产等结构。

项目里已经在做很多 Schema 层面的控制：Pydantic 模型、JSON mode、失败重试、结构化条件、悬空道具引用修复、v1.2 结构一致性检查。

这些逻辑更适合在代码里强约束，而不是完全交给平台 runtime。平台能帮我们把 Agent 跑起来，但不一定能很好承载这种细粒度的业务数据模型演进。

### 3.4 P0 要保留底层可替换性

当前代码里的 LLM 调用是通过 `openai` 库接 OpenAI-Compatible API。只要改 `base_url` 和模型配置，就能切 OpenAI、DeepSeek、火山方舟、智谱、通义等兼容服务。

这对 P0 很重要，因为我们还在验证不同环节应该用什么模型：长文本解析可能要长上下文模型，创意写作可能要文风更好的模型，一致性校验和结构化输出则更看重稳定性。

如果一开始就把逻辑深度绑定到某个平台 runtime，后续做模型 AB、私有化、降级策略、成本优化时，调整空间会变小。

### 3.5 不是说 AIME / Coze 不好，而是阶段不同

AIME / Coze 更适合在 P1 或更后面进入：当核心生成链路已经验证，Schema 稳定，用户入口、运营后台、权限、知识库、工具生态、发布链路都需要产品化时，再把部分能力平台化会更自然。

P0 先用 LangGraph，是为了把最难、最核心的业务链路打磨清楚。

---

## 4. LangChain 模型接口 vs 自己写适配层 vs openai 库：三种模型调用方式怎么选？

当前项目的模型调用在 `src/manhua_agent/llm.py` 里，采用的是“自己写一层轻量 LLMRouter，底层用 `openai` 库调用 OpenAI-Compatible 接口”。

可以把三种方式理解成三档：

| 方式 | 适合什么 | 优点 | 缺点 | 对当前项目的判断 |
| --- | --- | --- | --- | --- |
| LangChain 模型接口 | 已经大量使用 LangChain 生态，比如 Chain、Tool、Retriever、AgentExecutor | 接入统一，生态丰富，和 LangChain 其他模块组合方便 | 抽象层更厚，版本变化和封装细节可能增加调试成本 | P0 暂时没必要，因为我们没有重度使用 LangChain 全家桶 |
| 自己写适配层 | 需要统一多模型、多供应商、多角色策略 | 最灵活，能按 Parser / Writer / Consistency 等角色分配模型和温度 | 要自己维护错误处理、重试、日志、兼容细节 | 需要，但建议保持轻量，不要过早做成大平台 |
| 直接用 `openai` 库 | 接 OpenAI 或 OpenAI-Compatible 服务 | 简单、透明、依赖少，换兼容服务只改 base_url | 不自带复杂 Agent 能力，也不自动屏蔽所有厂商差异 | 很适合 P0，当前项目就是这个方向 |

### 4.1 LangChain 模型接口：适合“我已经在 LangChain 里了”

如果项目本身大量使用 LangChain 的 PromptTemplate、Runnable、Retriever、Tool、AgentExecutor，那么继续使用 LangChain 的模型接口会比较顺。

但当前项目最核心的流程编排在 LangGraph，业务数据结构在 Pydantic，模型调用需求也比较直接：给不同 Agent 角色发 messages，拿文本或 JSON 回来。

这时引入 LangChain 模型接口，收益没有那么大，反而会多一层抽象。

### 4.2 自己写适配层：适合“业务策略要自己掌控”

当前项目里已经有一个轻量适配层：`LLMRouter`。

它做了几件很关键的事：

| 能力 | 当前项目里的作用 |
| --- | --- |
| 按角色选模型 | Parser / Writer 可以单独配模型，其他角色走默认模型 |
| 按角色选温度 | Writer 更适合高温度，Consistency / Structurer 更适合低温度 |
| JSON 输出校验 | `chat_json` 会要求 JSON mode，并用 Pydantic Schema 校验 |
| 重试 | JSON 解析失败或校验失败时自动重试 |
| Embedding | 支线去重和长程记忆可以共用嵌入接口 |
| Dry-run fallback | 没配 API Key 时可以回落到 mock，保证工程链路能跑通 |

这层不是为了造轮子，而是为了把“模型怎么服务业务流程”这件事抓在自己手里。

### 4.3 直接用 `openai` 库：适合“P0 先跑通”

`openai` 库的好处是简单直观。当前大多数模型服务都支持 OpenAI-Compatible 协议，只要配置 `api_key`、`base_url`、`model`，就可以复用同一套调用方式。

对 P0 来说，这个选择很务实：先把生成质量、Schema 稳定性、流程闭环跑起来，不急着引入更重的模型框架。

后续如果发现某个供应商的接口差异很大，再在 `LLMRouter` 里加兼容分支即可，不影响上层 7 个 Agent 的业务逻辑。

---

## 5. P0 当前技术选型总结

### 5.1 P0 的关键词：轻、稳、可调试

P0 不追求最豪华的 Agent 平台，而是追求最短路径验证核心假设：

输入小说 / 关键词后，系统能否稳定产出一份可以被引擎加载的互动漫剧游戏 JSON。

所以当前选型可以总结为：

| 模块 | P0 选择 | 原因 |
| --- | --- | --- |
| 流程编排 | LangGraph，缺依赖时 fallback 到 sequential runner | 显式编排 7 个 Agent，支持条件回边，调试清楚 |
| Agent 形态 | Python 函数 + 明确角色 Prompt | 每个 Agent 职责固定，不让模型自由决定流程 |
| 数据结构 | Pydantic Schema | 强约束输出结构，便于校验、自修复和版本演进 |
| 模型调用 | 自写 `LLMRouter` + `openai` 库 | 轻量、透明、可接 OpenAI-Compatible 服务 |
| 结构化输出 | JSON mode + Pydantic 校验 + retry | 最终产物要能运行，不能只是一段看起来正确的文本 |
| 调试策略 | dry-run mock + verbose logs + full dump | 没有 API Key 也能跑链路，方便定位每一步问题 |

### 5.2 P0 这套架构的边界

P0 这套设计适合验证“生成链路是否成立”，但它不是最终形态。

它暂时不重点解决这些问题：多用户协作、权限系统、任务队列、素材生成调度、可视化编辑器、线上监控、成本看板、大规模并发、运营后台、复杂工具市场。

这些不是不重要，而是还没到最该花力气的时候。

P0 的正确姿势是：先让核心流水线产出可靠内容，再决定哪些能力值得产品化和平台化。

---

## 6. P1 可以怎么升级？

### 6.1 流程层：从串行流水线升级成“可观测生产线”

P0 是固定的 7 步串行流程。P1 可以继续保留 LangGraph，但把它升级成更完整的生产线：

| P1 升级点 | 价值 |
| --- | --- |
| 节点级缓存 | 小说解析、剧情规划这类高成本步骤不用每次重跑 |
| 人工审核断点 | 产品 / 编剧可以在 Planner 或 Writer 后介入修改 |
| 更细的回退策略 | 不一定整段重写，可以只重写某条支线或某个节点 |
| 并行生成 | 不同分支可以并行写作，再统一做一致性检查 |
| 任务状态面板 | 让用户看到正在解析、规划、写作、校验还是结构化 |

### 6.2 模型层：从“兼容调用”升级成“模型路由策略”

P0 只需要能切模型；P1 要开始关注质量、成本、速度的组合最优。

可以按环节做更细路由：Parser 用长上下文模型，Writer 用中文创作强的模型，Consistency 用低温稳定模型，Structurer 用 JSON 遵从度高的模型，Embedding 用成本低且稳定的向量模型。

还可以加入模型 AB：同一输入下比较不同模型产出的剧情质量、重复率、JSON 通过率和成本。

### 6.3 产品层：把“生成脚本”升级成“创作者工作台”

P1 最应该补的是可视化编辑器和模拟器。

因为互动漫剧不是生成完就结束，创作者一定会调分支、改台词、调数值、看结局到达率。P1 可以把 AI 初稿变成一个可编辑项目：左边是剧情树，右边是节点内容和数值配置，底部可以预跑玩家路径。

这时 LangGraph 仍然有用，因为每次用户修改后，可以只触发局部再生成或局部校验。

### 6.4 平台层：这时再考虑 AIME / Coze 或内部 Agent 平台

当 P1 需要对外发布、多人协作、接入更多工具、管理用户任务、做权限和审计时，AIME / Coze 这类平台能力就会更有价值。

比较合理的升级路线不是“把 LangGraph 扔掉”，而是：

```text
底层生成链路：继续用 LangGraph / Python 代码保证可控
上层产品入口：可以接 AIME / Coze / 自研工作台
工具与运营能力：逐步平台化
```

也就是说，LangGraph 负责“生产逻辑”，平台负责“产品体验和运营能力”。两者不是非此即彼。

---

## 7. 常见追问

### Q1：LangGraph 会不会太底层，产品化不方便？

会有一点。LangGraph 更偏工程编排，不是开箱即用的 Agent 产品平台。

但 P0 阶段，底层一点反而是好事。因为我们还在验证业务流程和数据结构，不希望过早被平台运行时限制住。等链路稳定后，再在上面包产品化入口更稳。

### Q2：LangChain 不是更有名吗，为什么不用它？

LangChain 很有名，但“有名”不等于“适合当前问题”。

它的 AgentExecutor 更适合开放式工具调用，而当前项目更像确定流程的内容生产线。我们需要的是显式状态机、条件回边和结构化产物流转，所以 LangGraph 更贴合。

### Q3：AIME / Coze 的工作流不也能编排吗？

能，但它们更偏平台化编排。对 P0 来说，我们需要频繁改 Schema、改节点逻辑、改回退规则、看中间状态。直接在代码里做，效率和可控性更高。

等到 P1 要做用户入口、运营、权限、任务管理时，再接平台会更合适。

### Q4：直接用 openai 库会不会太简陋？

不会。P0 的关键不是模型调用框架有多完整，而是流程和产物是否稳定。

当前 `LLMRouter` 已经补了关键业务能力：按 Agent 角色路由模型、控制温度、JSON Schema 校验、重试、Embedding 和 dry-run fallback。对现阶段来说，这比引入更重框架更合适。

### Q5：以后如果不用 OpenAI 协议怎么办？

可以在 `LLMRouter` 里加新的 client 适配。上层 Parser、Planner、Writer 等 Agent 不需要知道底层供应商怎么调。

这就是自己写轻量适配层的价值：底层可换，上层业务不动。

---

## 8. 一句话总结速查表

| 问题 | 一句话答案 |
| --- | --- |
| LangGraph 是什么？ | 一个适合把多 Agent 流程画成“状态图”的编排框架。 |
| LangChain 是什么？ | 一个 LLM 应用工具箱，尤其适合做工具调用、RAG、通用 Agent。 |
| AIME / Coze 是什么？ | 更产品化的 Agent 平台，适合配置 skill、工具、工作流并对外运营。 |
| 为什么 P0 选 LangGraph？ | 因为当前项目需要稳定的 7 步生成流水线，而不是自由发挥的通用 Agent。 |
| 为什么不选 LangChain AgentExecutor？ | AgentExecutor 太偏动态决策，我们这里更需要固定流程、清晰状态和可控回退。 |
| 为什么不直接上 AIME / Coze？ | P0 先验证核心生成链路，代码内控制 Schema、状态和自修复更高效。 |
| 为什么用 `openai` 库？ | 简单透明，能接 OpenAI-Compatible 服务，适合 P0 快速跑通。 |
| 为什么还要自己写 `LLMRouter`？ | 为了按 Agent 角色控制模型、温度、JSON 校验、重试和降级。 |
| P0 技术选型核心是什么？ | LangGraph 编排 + Pydantic Schema + OpenAI-Compatible 调用 + dry-run 可调试。 |
| P1 怎么升级？ | 保留底层生成链路，增加缓存、人工审核、并行生成、可视化编辑器和平台化入口。 |
| 最核心的一句话？ | LangGraph 管“生产流程”，openai 库管“模型连接”，AIME / Coze 更适合后续管“产品化运营”。 |
