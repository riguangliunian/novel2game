"""极简冒烟测试：验证 --dry-run 主链路无异常，并覆盖 v1.2 新 Schema。

运行方式：
    pip install -r requirements.txt
    PYTHONPATH=src python3 -m tests.smoke_test
"""

from __future__ import annotations

from manhua_agent import PipelineConfig, run_pipeline
from manhua_agent.models import (
    And_,
    Condition,
    EvalState,
    HasItem,
    Or_,
    VarCmp,
    parse_condition,
    render_condition,
)


def test_keywords_dry_run() -> None:
    result = run_pipeline(
        PipelineConfig(
            mode="keywords",
            keywords=["民国", "推理", "双男主"],
            theme="1930 年代上海侦探故事",
            branch_count=3,
            staging="semi-dynamic",
            dry_run=True,
        )
    )
    assert result.game.story_tree.nodes, "应生成至少一个节点"
    assert len(result.game.story_tree.endings) == 3, "分支数应等于结局数"
    assert result.game.story_tree.start_node in {n.id for n in result.game.story_tree.nodes}
    # goto 完整性
    node_ids = {n.id for n in result.game.story_tree.nodes}
    for n in result.game.story_tree.nodes:
        for c in n.choices:
            assert c.goto in node_ids, f"goto 引用失败: {c.goto}"

    # v1.2：schema_version 与 assets/幕章
    assert result.game.schema_version == "1.2"
    assert result.game.acts, "v1.2 应产出 acts"
    assert result.game.assets.items, "v1.2 应产出至少一件道具"
    assert result.game.assets.scenes, "v1.2 应产出至少一个 Scene"
    assert result.game.assets.bgms, "v1.2 应产出至少一个 BGM"

    # v1.2：至少有一个节点填了 act_id/chapter_id/segment_order + scene_id
    hierarchical = [n for n in result.game.story_tree.nodes if n.act_id or n.chapter_id]
    assert hierarchical, "应有节点带幕/章层级信息"
    scene_tagged = [n for n in result.game.story_tree.nodes if n.scene_id]
    assert scene_tagged, "应有节点带 scene_id"

    # v1.2：Condition AST 必须是结构化对象（不是字符串）
    for e in result.game.story_tree.endings:
        assert isinstance(e.unlock, (VarCmp, And_, Or_, HasItem)), (
            f"Ending.unlock 应是 Condition 对象，实际是 {type(e.unlock)}"
        )

    # v1.2：Condition.evaluate 应可直接执行
    state = EvalState(variables=result.game.variables)
    for e in result.game.story_tree.endings:
        _ = e.unlock.evaluate(state)  # 不抛异常即视为通过

    # v1.2：serialize 后再 load 保持不变
    dumped = result.game.model_dump_json()
    from manhua_agent.models import GameOutput

    loaded = GameOutput.model_validate_json(dumped)
    assert loaded.schema_version == "1.2"
    assert len(loaded.assets.items) == len(result.game.assets.items)

    print("✔ keywords dry-run 通过")


def test_novel_dry_run() -> None:
    result = run_pipeline(
        PipelineConfig(
            mode="novel",
            novel_text="很久很久以前……" * 100,
            branch_count=2,
            staging="static",
            dry_run=True,
        )
    )
    assert result.game.story_tree.nodes
    # static 硬约束
    for n in result.game.story_tree.nodes:
        assert n.staging == "static", f"static 档位下不应出现 {n.staging}"
    print("✔ novel dry-run + static tier 通过")


def test_condition_backward_compat() -> None:
    """v1.2：v1.1 字符串条件必须被自动 parse 为 Condition AST 并可 evaluate。"""
    # 1. parse_condition 单独工作
    cond = parse_condition("好感度>=60 && 勇气>=40")
    assert cond is not None
    assert isinstance(cond, And_)
    assert render_condition(cond) == "(好感度>=60) && (勇气>=40)"

    # 2. evaluate
    assert cond.evaluate(EvalState(variables={"好感度": 70, "勇气": 50})) is True
    assert cond.evaluate(EvalState(variables={"好感度": 70, "勇气": 30})) is False

    # 3. Choice 传字符串自动升级
    from manhua_agent.models import Choice

    ch = Choice(text="x", goto="y", requires="好感度>=30")
    assert isinstance(ch.requires, VarCmp), "字符串应被 parse 为 VarCmp"
    assert ch.requires.evaluate(EvalState(variables={"好感度": 40})) is True

    # 4. Ending 传字符串自动升级
    from manhua_agent.models import Ending

    e = Ending(id="e1", title="T", unlock="勇气>=20 && 金钱>=5")
    assert isinstance(e.unlock, And_)
    assert (
        e.unlock.evaluate(EvalState(variables={"勇气": 25, "金钱": 10})) is True
    )

    # 5. Or / 括号
    cond2 = parse_condition("好感度>=60 || (勇气>=40 && 金钱>=10)")
    assert isinstance(cond2, Or_)
    assert cond2.evaluate(EvalState(variables={"好感度": 100})) is True
    assert cond2.evaluate(EvalState(variables={"勇气": 50, "金钱": 20})) is True
    assert cond2.evaluate(EvalState(variables={"勇气": 50, "金钱": 5})) is False

    print("✔ Condition 向后兼容测试通过")


if __name__ == "__main__":
    test_keywords_dry_run()
    test_novel_dry_run()
    test_condition_backward_compat()
    print("\nAll smoke tests passed.")
