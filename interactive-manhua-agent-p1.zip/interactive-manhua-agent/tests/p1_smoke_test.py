"""P1 冒烟测试：分阶段执行器（HITL）、动静决策、导出、Web API。

不依赖任何外部 API Key，全程 dry-run。运行：
    python tests/p1_smoke_test.py
"""

from __future__ import annotations

import sys
import time
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


def test_stepwise_hitl():
    from manhua_agent.config import PipelineConfig
    from manhua_agent.pipeline_steps import PipelineSession

    cfg = PipelineConfig(mode="keywords", keywords=["宫斗", "复仇"], dry_run=True, branch_count=2)
    s = PipelineSession(config=cfg)
    skeleton = s.run_until_plan()
    assert s.stage == "planned"
    assert len(skeleton.branches) >= 1
    # 模拟人工编辑分支
    skeleton.branches[0].label = "已编辑分支"
    s.apply_skeleton(skeleton)
    game = s.run_after_plan()
    assert s.stage == "finished"
    assert len(game.story_tree.nodes) > 0
    assert game.story_tree.start_node
    print("✔ 分阶段执行 + HITL 编辑 通过")


def test_media_decision():
    import json

    from manhua_agent.assets import decide_media_types
    from manhua_agent.models import GameOutput

    sample = Path(__file__).resolve().parents[1] / "output" / "game.json"
    if not sample.exists():
        # 生成一份
        from manhua_agent.config import PipelineConfig
        from manhua_agent.graph import run_pipeline

        game = run_pipeline(PipelineConfig(mode="keywords", keywords=["测试"], dry_run=True))
    else:
        game = GameOutput.model_validate(json.load(open(sample, encoding="utf-8")))

    total = len(game.story_tree.nodes)
    for ratio in (0.0, 0.2, 0.5, 1.0):
        counts = decide_media_types(game.story_tree.nodes, ratio)
        assert counts["image"] + counts["video"] == total
        assert counts["video"] == round(ratio * total), (ratio, counts)
    print("✔ 动静混合决策（video_ratio 可控）通过")


def test_export_zip():
    import json

    from manhua_agent.assets import decide_media_types
    from manhua_agent.exporter import export_game
    from manhua_agent.models import GameOutput

    sample = Path(__file__).resolve().parents[1] / "output" / "game.json"
    game = GameOutput.model_validate(json.load(open(sample, encoding="utf-8")))
    decide_media_types(game.story_tree.nodes, 0.2)
    out = Path(__file__).resolve().parents[1] / "output" / "_p1_test_export.zip"
    res = export_game(game, out)
    assert res.has_index and not res.oversize
    with zipfile.ZipFile(out) as z:
        names = z.namelist()
        assert "index.html" in names, names
        assert "game-data.js" in names and "player.js" in names
    out.unlink(missing_ok=True)
    print("✔ 导出 zip（根目录含 index.html，≤8M）通过")


def test_web_api():
    from fastapi.testclient import TestClient

    from manhua_agent.server.app import create_app

    c = TestClient(create_app())
    assert c.get("/api/config").status_code == 200
    assert c.get("/").status_code == 200
    r = c.post("/api/jobs", json={"mode": "keywords", "keywords": ["宫斗"], "dry_run": True, "branch_count": 2})
    jid = r.json()["job_id"]

    def wait(targets, timeout=30):
        t0 = time.time()
        while time.time() - t0 < timeout:
            s = c.get(f"/api/jobs/{jid}/status").json()
            if s["status"] in targets or s["status"] == "error":
                return s
            time.sleep(0.3)
        return s

    s = wait({"awaiting_confirm"})
    assert s["status"] == "awaiting_confirm", s
    sk = c.get(f"/api/jobs/{jid}/skeleton").json()
    assert c.post(f"/api/jobs/{jid}/confirm", json={"skeleton": sk}).status_code == 200
    s = wait({"finished"})
    assert s["status"] == "finished", s
    assert c.get(f"/api/jobs/{jid}/game").status_code == 200
    ex = c.post(f"/api/jobs/{jid}/export").json()
    assert ex["has_index"] and not ex["oversize"]
    assert c.get(f"/api/jobs/{jid}/download").status_code == 200
    print("✔ Web API 全链路（create→HITL→finish→export→download）通过")


if __name__ == "__main__":
    test_stepwise_hitl()
    test_media_decision()
    test_export_zip()
    test_web_api()
    print("\nAll P1 smoke tests passed.")
