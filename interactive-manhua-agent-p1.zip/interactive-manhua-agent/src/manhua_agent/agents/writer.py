"""③ 写作 Agent (Writer).

按分支逐条展开节点，避免整篇一次写；每次生成时把已生成的其他分支摘要作为
「显式差异化约束」加进 prompt，落实文档 4.3 第 2 条。

v1.2 起：为每个节点填 `act_id / chapter_id / segment_order`；根据 beat 位置
猜测节点内容类型（首末段用 narration 或 inner_monologue，中段可能是 dialogue）。
"""

from __future__ import annotations

from typing import List

from pydantic import BaseModel

from ..config import PipelineConfig
from ..llm import LLMRouter
from ..models import BranchSkeleton, Node, NodeType, StorySetting, StorySkeleton
from ..prompts import WRITER_SYSTEM


class _NodesResponse(BaseModel):
    """LLM 返回的 nodes 包装。"""

    nodes: List[Node]


def run_writer(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    router: LLMRouter,
) -> List[Node]:
    """逐分支生成节点。前置分支摘要作为差异化约束注入下一分支 prompt。"""

    all_nodes: List[Node] = []
    prior_summaries: List[str] = []
    for branch in skeleton.branches:
        diff_hint = "、".join(prior_summaries) if prior_summaries else "（无）"
        chapter_hint = (
            f"分支归属：act={branch.act_id}, chapters={branch.chapter_ids}\n"
            if branch.act_id or branch.chapter_ids
            else ""
        )
        user_msg = (
            f"作品：《{setting.title}》。请为分支 [{branch.id}] {branch.label} 展开节点。\n\n"
            f"{chapter_hint}"
            f"分支冲突源：{branch.conflict_source}\n"
            f"分支结局走向：{branch.ending_direction}\n"
            f"关键道具：{', '.join(branch.key_props) or '无'}\n"
            f"节拍大纲：\n" + "\n".join(f"- {b}" for b in branch.beats) + "\n\n"
            f"**差异化硬约束**：本分支必须显著区别于以下已生成支线的：冲突源/结局/关键道具/关键桥段。\n"
            f"已生成支线摘要：{diff_hint}\n\n"
            f"v1.2 要求：\n"
            f"- 逐条节拍展开为节点，每个节点 60-150 字，标注 emotion_intensity。\n"
            f"- 请填 act_id/chapter_id/segment_order（本分支内节点顺序 1..N）。\n"
            f"- 节点 type 可选：dialogue / narration / inner_monologue / system / status_change。\n"
            f"  首末段偏 narration，中段可 dialogue 或 inner_monologue，涉及数值变化用 status_change。\n"
            f"- 不生成 choice/ending/minigame——那是游戏化 Agent 的活。"
        )
        temperature = router.settings.temperature_creative
        resp = router.chat_json(
            role="writer",
            messages=[
                {"role": "system", "content": WRITER_SYSTEM},
                {"role": "user", "content": user_msg},
            ],
            schema=_NodesResponse,
            temperature=temperature,
        )
        for node in resp.nodes:
            node.branch_id = branch.id
            if not node.act_id and branch.act_id:
                node.act_id = branch.act_id
        all_nodes.extend(resp.nodes)
        prior_summaries.append(f"[{branch.id}] {branch.label}: {branch.ending_direction}")
    return all_nodes


def _guess_content_type(idx: int, total: int) -> NodeType:
    """v1.2：根据节拍位置猜测内容类型。

    首段 narration（引入）；末段 narration（收束）；中段偶数 inner_monologue、
    奇数 dialogue——多样性优先，让前端渲染切分能力有用武之地。
    """
    if idx == 1:
        return "narration"
    if idx == total:
        return "narration"
    return "dialogue" if idx % 2 == 1 else "inner_monologue"


def mock_writer(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
) -> List[Node]:
    """规则占位：为每个节拍生成一段样板文本；v1.2 补齐幕/章/段与内容类型。"""
    nodes: List[Node] = []
    protagonist = setting.characters[0].name if setting.characters else "主角"
    for branch in skeleton.branches:
        total = len(branch.beats)
        # 分支章节列表：intro 用于中间大部分节点、climax 用于末段
        intro_chapter = branch.chapter_ids[0] if branch.chapter_ids else None
        climax_chapter = (
            branch.chapter_ids[-1] if branch.chapter_ids else intro_chapter
        )
        for idx, beat in enumerate(branch.beats, 1):
            emotion = min(0.3 + idx * 0.12, 0.95)
            ctype = _guess_content_type(idx, total)
            chapter_id = climax_chapter if idx == total else intro_chapter
            act_id = branch.act_id or ("act_3" if idx == total else "act_2")
            character = protagonist if ctype in ("dialogue", "inner_monologue") else None
            nodes.append(
                Node(
                    id=f"n_{branch.id}_{idx:02d}",
                    type=ctype,
                    branch_id=branch.id,
                    character=character,
                    content=(
                        f"【{branch.label} · 第{idx}幕】{beat}。"
                        f"（{protagonist}的心跳因此加速，事态正朝着{branch.ending_direction}的方向倾斜。）"
                    ),
                    emotion_intensity=emotion,
                    act_id=act_id,
                    chapter_id=chapter_id,
                    segment_order=idx,
                )
            )
    return nodes
