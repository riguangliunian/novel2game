"""⑥ 演出设计 Agent (Direction / Staging).

按 emotion_intensity + 用户档位约束，为每个节点分配 static / semi-dynamic / full-video，
并生成 asset_prompt（作为后续 图像/视频 生成模块的输入）。

v1.2：把 `asset_prompt` 拆解为结构化字段（scene_id/location/background/camera/bgm_id/cg_id/voiceover），
`asset_prompt` 仍作为汇总兜底保留。多个 node 复用同一 scene_id 时，
在 `Assets.scenes` 里注册去重后的 Scene 对象；BGM 也按情绪强度归档。

素材实际生成（可灵/Seedream/Seedance）本 MVP 未接入，
`dispatch_asset_generation()` 为预留占位。
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from pydantic import BaseModel

from ..config import PipelineConfig, StagingTier
from ..llm import LLMRouter
from ..models import BGM, CG, Node, Scene, StorySetting, Voiceover
from ..prompts import DIRECTION_SYSTEM

# 用户档位与建议档位允许的最高档
_TIER_RANK = {"static": 0, "semi-dynamic": 1, "full-video": 2}


class _StagedResponse(BaseModel):
    nodes: List[Node]


def _cap_by_user_tier(suggested: StagingTier, user_max: StagingTier) -> StagingTier:
    if _TIER_RANK[suggested] <= _TIER_RANK[user_max]:
        return suggested
    return user_max


def _suggest_by_emotion(intensity: float) -> StagingTier:
    if intensity < 0.4:
        return "static"
    if intensity < 0.7:
        return "semi-dynamic"
    return "full-video"


def _suggest_bgm_id(intensity: float) -> str:
    """按情绪强度归档 BGM ID。低情绪 → 舒缓；高情绪 → 激烈。"""
    if intensity < 0.4:
        return "bgm_calm"
    if intensity < 0.7:
        return "bgm_tense"
    return "bgm_climax"


def run_direction(
    config: PipelineConfig,
    setting: StorySetting,
    nodes: List[Node],
    router: LLMRouter,
) -> Tuple[List[Node], List[Scene], List[BGM], List[CG], List[Voiceover]]:
    user_msg = (
        f"作品：《{setting.title}》\n"
        f"用户选择的最高档位：{config.staging}\n"
        f"档位定义：static=静态；semi-dynamic=局部动效；full-video=完整视频。\n\n"
        "节点列表：\n"
        + "\n".join(
            f"- {n.id} | type={n.type} | emotion={n.emotion_intensity} | content={n.content[:80]}"
            for n in nodes
        )
        + "\n\n请为每个节点填入 staging，以及 v1.2 的细粒度演出字段："
        + "scene_id/location/background/camera/bgm_id/cg_id/voiceover；"
        + "同时保留一份汇总 asset_prompt 供素材流水线兜底。"
    )
    resp = router.chat_json(
        role="direction",
        messages=[
            {"role": "system", "content": DIRECTION_SYSTEM},
            {"role": "user", "content": user_msg},
        ],
        schema=_StagedResponse,
    )
    # 二次兜底：用户档位硬约束
    for node in resp.nodes:
        node.staging = _cap_by_user_tier(node.staging, config.staging)
    scenes, bgms, cgs, voiceovers = _collect_assets(resp.nodes, setting)
    return resp.nodes, scenes, bgms, cgs, voiceovers


def mock_direction(
    config: PipelineConfig, setting: StorySetting, nodes: List[Node]
) -> Tuple[List[Node], List[Scene], List[BGM], List[CG], List[Voiceover]]:
    """规则占位：v1.2 版本——拆解 asset_prompt，注册 Scene/BGM/CG/Voiceover。"""
    protagonist = setting.characters[0].name if setting.characters else "主角"
    for node in nodes:
        suggested = _suggest_by_emotion(node.emotion_intensity)
        node.staging = _cap_by_user_tier(suggested, config.staging)
        char = node.character or protagonist
        camera = (
            "特写镜头"
            if node.emotion_intensity > 0.7
            else "中景"
            if node.emotion_intensity > 0.4
            else "远景"
        )
        # v1.2：结构化字段
        # scene_id 按 act_id 归档：同一幕内共享一个 scene（简化占位；真实生成会按内容聚类）
        act_key = node.act_id or "act_default"
        node.scene_id = f"s_{act_key}"
        node.location = f"{setting.worldview.location}·{act_key}"
        node.background = (
            f"{setting.worldview.era}·{setting.worldview.location}氛围底图"
        )
        node.camera = camera
        node.bgm_id = _suggest_bgm_id(node.emotion_intensity)
        # 高情绪节点才配 CG
        if node.emotion_intensity > 0.7:
            node.cg_id = f"cg_{node.id}"
        # 内心独白/系统提示配特殊 voiceover 音色
        if node.type == "inner_monologue":
            node.voiceover = f"vo_inner_{char}"
        elif node.type == "system":
            node.voiceover = "vo_system"
        else:
            node.voiceover = None

        # 保留 asset_prompt 作为汇总兜底字段
        node.asset_prompt = (
            f"{char}，{setting.worldview.era}·{setting.worldview.location}，"
            f"情绪强度{node.emotion_intensity:.1f}，{camera}，{node.content[:40]}……"
        )
    scenes, bgms, cgs, voiceovers = _collect_assets(nodes, setting)
    return nodes, scenes, bgms, cgs, voiceovers


def _collect_assets(
    nodes: List[Node], setting: StorySetting
) -> Tuple[List[Scene], List[BGM], List[CG], List[Voiceover]]:
    """从节点里去重收集 Scene/BGM/CG/Voiceover 资产池。"""
    scene_dict: Dict[str, Scene] = {}
    bgm_dict: Dict[str, BGM] = {}
    cg_dict: Dict[str, CG] = {}
    vo_dict: Dict[str, Voiceover] = {}
    for n in nodes:
        if n.scene_id and n.scene_id not in scene_dict:
            scene_dict[n.scene_id] = Scene(
                id=n.scene_id,
                location=n.location or setting.worldview.location,
                background=n.background,
                description=f"由节点 {n.id} 首次登场的场景",
                default_bgm_id=n.bgm_id,
            )
        if n.bgm_id and n.bgm_id not in bgm_dict:
            bgm_dict[n.bgm_id] = BGM(
                id=n.bgm_id,
                name={
                    "bgm_calm": "舒缓·日常",
                    "bgm_tense": "紧张·推进",
                    "bgm_climax": "激烈·高潮",
                }.get(n.bgm_id, n.bgm_id),
                description="按情绪强度自动分档",
            )
        if n.cg_id and n.cg_id not in cg_dict:
            cg_dict[n.cg_id] = CG(
                id=n.cg_id,
                description=f"节点 {n.id} 的高情绪 CG",
                scene_id=n.scene_id,
            )
        if n.voiceover and n.voiceover not in vo_dict:
            vo_dict[n.voiceover] = Voiceover(
                id=n.voiceover,
                speaker=n.character or "系统",
                text=None,
            )
    return (
        list(scene_dict.values()),
        list(bgm_dict.values()),
        list(cg_dict.values()),
        list(vo_dict.values()),
    )


def dispatch_asset_generation(nodes: List[Node]) -> None:
    """预留：把 semi-dynamic / full-video 节点的 asset_prompt 提交到素材生成流水线。

    后续可接入 可灵 / Seedream（图）和 Seedance / 可灵视频（视频）。
    """
    # TODO: connect to actual asset generation providers
    pass
