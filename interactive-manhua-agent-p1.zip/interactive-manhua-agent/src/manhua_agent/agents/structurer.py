"""⑦ 结构化输出 Agent (Structured Output).

把前序所有产物合并成一个可被引擎直接加载的 GameOutput，
并做「goto 引用完整性 / start_node / 变量一致性」的最终校验。

v1.2 新增自修复：
1. `consume_items` 必须已被 `requires_items` 或某个 Node.gain_items 覆盖（否则去掉）；
2. `Condition` 里引用的变量必须在 variables 表中（否则补 0）；
3. `Condition` / gain_items / consume_items / requires_items 引用的 item_id 必须
   在 items 池里（否则去掉引用，避免下游 NPE）。

产品文档 4.2 表格最后一行：强制 JSON schema，出错回退重试而非自由文本。
"""

from __future__ import annotations

from typing import Iterable, List, Optional, Set, Tuple

from ..config import PipelineConfig
from ..llm import LLMRouter  # noqa: F401 — reserved for future LLM-driven merge
from ..models import (
    And_,
    Assets,
    BGM,
    CG,
    Character,
    Choice,
    Condition,
    Ending,
    GameOutput,
    HasItem,
    Item,
    Node,
    Not_,
    Or_,
    Scene,
    StorySetting,
    StorySkeleton,
    StoryTree,
    VarCmp,
    Voiceover,
)


def _self_repair(
    nodes: List[Node],
    endings: List[Ending],
    items: List[Item],
    variables_keys: Set[str],
) -> Tuple[List[Node], List[Ending], str]:
    """校验 goto/道具/变量引用完整性，返回修复后的 nodes 与 start_node。

    - 不存在的 goto 会被重定向到该分支的第一个 ending 节点（fail-open 兜底）。
    - v1.2：consume_items 未在 requires_items 或既有 gain_items 中的，去掉。
    - v1.2：Condition 引用的变量/道具不存在时打补丁。
    """
    node_ids = {n.id for n in nodes}
    item_ids = {it.id for it in items}
    ending_id_by_branch: dict[str, str] = {}
    for n in nodes:
        if n.type == "ending" and n.branch_id:
            ending_id_by_branch.setdefault(n.branch_id, n.id)

    # 汇总每个分支上已 gain 到的道具（简化：只看直接 gain，不做路径推理；
    # 存在但未持有的 consume 由运行时判断，此处只是防止「item_id 完全没被生产过」）
    produced_items: Set[str] = set()
    for n in nodes:
        produced_items.update(n.gain_items)
        for c in n.choices:
            produced_items.update(c.gain_items)

    for n in nodes:
        # goto 修复
        for choice in n.choices:
            if choice.goto not in node_ids:
                fallback = ending_id_by_branch.get(n.branch_id or "") or (
                    next(iter(ending_id_by_branch.values())) if ending_id_by_branch else n.id
                )
                choice.goto = fallback
            # 道具引用清洗
            choice.requires_items = [it for it in choice.requires_items if it in item_ids]
            choice.gain_items = [it for it in choice.gain_items if it in item_ids]
            choice.consume_items = [
                it
                for it in choice.consume_items
                if it in item_ids
                and (it in choice.requires_items or it in produced_items)
            ]
            # Condition 补丁
            if choice.requires is not None:
                choice.requires = _repair_condition(
                    choice.requires, variables_keys, item_ids
                )
        # 节点层道具引用清洗
        n.gain_items = [it for it in n.gain_items if it in item_ids]
        n.consume_items = [
            it for it in n.consume_items if it in item_ids and it in produced_items
        ]
        # 修 minigame goto
        if n.minigame:
            if n.minigame.on_success not in node_ids:
                n.minigame.on_success = ending_id_by_branch.get(n.branch_id or "", n.id)
            if n.minigame.on_failure and n.minigame.on_failure not in node_ids:
                n.minigame.on_failure = ending_id_by_branch.get(n.branch_id or "", n.id)

    # ending unlock 修复
    for e in endings:
        e.unlock = _repair_condition(e.unlock, variables_keys, item_ids)

    start = next((n.id for n in nodes if n.type != "ending"), nodes[0].id if nodes else "n_start")
    return nodes, endings, start


def _repair_condition(
    cond: Condition,
    variables_keys: Set[str],
    item_ids: Set[str],
) -> Condition:
    """v1.2：递归修复 Condition。

    - VarCmp.var 不在变量表 → 保留字段，但把 value 拉到最宽松的 0（>= 0 恒真）。
      同时把原变量名写进 expression，方便后续人工修补。
    - HasItem.item_id 不在 items 池 → 降级为「恒真」的 VarCmp(var=_expr, op=>=, value=0)。
    - And_ / Or_ / Not_ 递归修复。
    """
    if isinstance(cond, VarCmp):
        if cond.var not in variables_keys and cond.var != "_expr":
            note = f"[修复] 变量 {cond.var!r} 不在 variables 表中，已放宽为恒真"
            return VarCmp(
                var="_expr",
                op=">=",
                value=0,
                expression=cond.expression or note,
            )  # type: ignore[arg-type]
        return cond
    if isinstance(cond, HasItem):
        if cond.item_id not in item_ids:
            return VarCmp(
                var="_expr",
                op=">=",
                value=0,
                expression=cond.expression
                or f"[修复] 道具 {cond.item_id!r} 未在 items 池中定义，已放宽为恒真",
            )  # type: ignore[arg-type]
        return cond
    if isinstance(cond, And_):
        cond.conditions = [
            _repair_condition(c, variables_keys, item_ids) for c in cond.conditions
        ]
        return cond
    if isinstance(cond, Or_):
        cond.conditions = [
            _repair_condition(c, variables_keys, item_ids) for c in cond.conditions
        ]
        return cond
    if isinstance(cond, Not_):
        cond.condition = _repair_condition(cond.condition, variables_keys, item_ids)
        return cond
    return cond


def run_structurer(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    nodes: List[Node],
    endings: List[Ending],
    items: Optional[List[Item]] = None,
    scenes: Optional[List[Scene]] = None,
    bgms: Optional[List[BGM]] = None,
    cgs: Optional[List[CG]] = None,
    voiceovers: Optional[List[Voiceover]] = None,
) -> GameOutput:
    """结构化输出 Agent 采用「规则合并 + 自修复」策略，稳定性高于纯 LLM 合并。

    如需 LLM 参与，可在这里替换成 router.chat_json(schema=GameOutput)。
    """
    items = items or []
    scenes = scenes or []
    bgms = bgms or []
    cgs = cgs or []
    voiceovers = voiceovers or []
    variables_keys = set(skeleton.variables.keys())
    fixed_nodes, fixed_endings, start_node = _self_repair(
        nodes, endings, items, variables_keys
    )

    # v1.2：把 skeleton/setting 的 acts/chapters 合并优先级：skeleton 覆盖 setting
    acts = skeleton.acts or setting.acts
    chapters = skeleton.chapters or setting.chapters

    return GameOutput(
        schema_version="1.2",
        title=setting.title,
        logline=setting.logline,
        genre=setting.genre,
        variables=skeleton.variables,
        story_tree=StoryTree(
            nodes=fixed_nodes, endings=fixed_endings, start_node=start_node
        ),
        assets=Assets(
            characters=[_character_view(c) for c in setting.characters],
            scenes=scenes,
            items=items,
            bgms=bgms,
            cgs=cgs,
            voiceovers=voiceovers,
        ),
        acts=acts,
        chapters=chapters,
        metadata={
            "schema_version": "1.2",
            "branch_count": len(skeleton.branches),
            "node_count": len(fixed_nodes),
            "ending_count": len(fixed_endings),
            "item_count": len(items),
            "scene_count": len(scenes),
            "bgm_count": len(bgms),
            "cg_count": len(cgs),
            "voiceover_count": len(voiceovers),
            "act_count": len(acts) if acts else 0,
            "chapter_count": len(chapters) if chapters else 0,
            "staging_tier": config.staging,
        },
    )


def mock_structurer(
    config: PipelineConfig,
    setting: StorySetting,
    skeleton: StorySkeleton,
    nodes: List[Node],
    endings: List[Ending],
    items: Optional[List[Item]] = None,
    scenes: Optional[List[Scene]] = None,
    bgms: Optional[List[BGM]] = None,
    cgs: Optional[List[CG]] = None,
    voiceovers: Optional[List[Voiceover]] = None,
) -> GameOutput:
    # 结构化输出本身就是纯规则合并，dry-run 与真实调用共用同一实现。
    return run_structurer(
        config,
        setting,
        skeleton,
        nodes,
        endings,
        items=items,
        scenes=scenes,
        bgms=bgms,
        cgs=cgs,
        voiceovers=voiceovers,
    )


def _character_view(c: Character) -> Character:
    """Assets.characters 复用 StorySetting.characters，剥离 motivation 之类的可选字段可选。"""
    return c
