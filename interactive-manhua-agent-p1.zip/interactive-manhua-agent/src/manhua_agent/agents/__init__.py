"""七个 Agent 的实现。每个 Agent 都提供:

- 一个 `run_*` 函数，读入前序 artifact，输出下一 artifact
- 一个 `mock_*` 函数，无 LLM 时用规则生成占位数据（供 --dry-run 使用）

这样在 graph.py 里，节点函数只是分发器：
    if config.dry_run: mock_*()
    else: run_*()
"""

from .parser import mock_parser, run_parser
from .planner import mock_planner, run_planner
from .writer import mock_writer, run_writer
from .consistency import mock_consistency, run_consistency
from .gamification import mock_gamification, run_gamification
from .direction import mock_direction, run_direction
from .structurer import mock_structurer, run_structurer

__all__ = [
    "run_parser", "mock_parser",
    "run_planner", "mock_planner",
    "run_writer", "mock_writer",
    "run_consistency", "mock_consistency",
    "run_gamification", "mock_gamification",
    "run_direction", "mock_direction",
    "run_structurer", "mock_structurer",
]
