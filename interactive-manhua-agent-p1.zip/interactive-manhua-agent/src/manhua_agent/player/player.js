/* ==========================================================================
 * 互动漫剧 H5 播放器引擎（预览与导出共用）
 *
 * 用法：
 *   ManhuaPlayer.mount(container, game, { assetBase: '' });
 *
 * - game：GameOutput（schema 1.2）对象
 * - assetBase：素材相对路径前缀。导出包内为 ''（同目录），预览时为
 *   '/api/jobs/<id>/'（后端提供素材静态服务）。节点 media_url 形如
 *   'assets/n_xxx.png'，最终 src = assetBase + media_url。
 * ========================================================================== */
(function (global) {
  "use strict";

  // ------------------------- 条件 AST 求值 ------------------------- //
  function evalCond(cond, state) {
    if (!cond) return true;
    switch (cond.type) {
      case "var_cmp": {
        const v = state.variables[cond.var] || 0;
        switch (cond.op) {
          case ">": return v > cond.value;
          case ">=": return v >= cond.value;
          case "<": return v < cond.value;
          case "<=": return v <= cond.value;
          case "==": return v === cond.value;
          case "!=": return v !== cond.value;
          default: return true;
        }
      }
      case "has_item":
        return (state.inventory[cond.item_id] || 0) >= (cond.min_count || 1);
      case "choice_taken":
        return state.taken.has(cond.node_id + "#" + cond.choice_index);
      case "and":
        return (cond.conditions || []).every((c) => evalCond(c, state));
      case "or":
        return (cond.conditions || []).some((c) => evalCond(c, state));
      case "not":
        return !evalCond(cond.condition, state);
      default:
        return true;
    }
  }

  function renderCond(cond) {
    if (!cond) return "";
    if (cond.expression) return cond.expression;
    switch (cond.type) {
      case "var_cmp": return `${cond.var}${cond.op}${cond.value}`;
      case "has_item": return `需要道具`;
      case "and": return (cond.conditions || []).map(renderCond).join(" 且 ");
      case "or": return (cond.conditions || []).map(renderCond).join(" 或 ");
      case "not": return "非(" + renderCond(cond.condition) + ")";
      default: return "";
    }
  }

  // ------------------------- 播放器类 ------------------------- //
  function Player(container, game, opts) {
    this.el = container;
    this.game = game;
    this.opts = opts || {};
    this.assetBase = this.opts.assetBase || "";
    this.nodeMap = {};
    (game.story_tree.nodes || []).forEach((n) => (this.nodeMap[n.id] = n));
    this.nodeOrder = (game.story_tree.nodes || []).map((n) => n.id);
    this.itemMap = {};
    ((game.assets && game.assets.items) || []).forEach((it) => (this.itemMap[it.id] = it));
    this.endings = game.story_tree.endings || [];
    this.reset();
  }

  Player.prototype.reset = function () {
    this.state = {
      variables: Object.assign({}, this.game.variables || {}),
      inventory: {},
      taken: new Set(),
    };
    this.el.classList.add("mh-root");
    this.el.innerHTML = "";
    this._buildShell();
    this.show(this.game.story_tree.start_node);
  };

  Player.prototype._buildShell = function () {
    const g = this.game;
    this.el.innerHTML = `
      <div class="mh-stage" data-mh="stage"></div>
      <div class="mh-topbar">
        <span class="mh-title">${esc(g.title || "互动漫剧")}</span>
        <button class="mh-restart" data-mh="restart">↺ 重玩</button>
      </div>
      <div class="mh-hud" data-mh="hud"></div>
      <div class="mh-toast" data-mh="toast"></div>
      <div class="mh-bottom" data-mh="bottom"></div>
    `;
    const self = this;
    this.el.querySelector('[data-mh="restart"]').onclick = function () {
      self.reset();
    };
    this.$stage = this.el.querySelector('[data-mh="stage"]');
    this.$hud = this.el.querySelector('[data-mh="hud"]');
    this.$bottom = this.el.querySelector('[data-mh="bottom"]');
    this.$toast = this.el.querySelector('[data-mh="toast"]');
  };

  Player.prototype.toast = function (msg) {
    if (!msg) return;
    this.$toast.textContent = msg;
    this.$toast.classList.add("mh-show");
    clearTimeout(this._toastT);
    const self = this;
    this._toastT = setTimeout(() => self.$toast.classList.remove("mh-show"), 1400);
  };

  Player.prototype._applyItems = function (gain, consume, effects) {
    const inv = this.state.inventory;
    const notes = [];
    (gain || []).forEach((id) => {
      inv[id] = (inv[id] || 0) + 1;
      const it = this.itemMap[id];
      notes.push("获得「" + (it ? it.name : id) + "」");
    });
    (consume || []).forEach((id) => {
      if (inv[id]) inv[id] -= 1;
      if (inv[id] <= 0) delete inv[id];
      const it = this.itemMap[id];
      notes.push("消耗「" + (it ? it.name : id) + "」");
    });
    if (effects) {
      Object.keys(effects).forEach((k) => {
        this.state.variables[k] = (this.state.variables[k] || 0) + effects[k];
        notes.push(k + (effects[k] >= 0 ? " +" : " ") + effects[k]);
      });
    }
    if (notes.length) this.toast(notes.join("  "));
  };

  Player.prototype.show = function (nodeId) {
    const node = this.nodeMap[nodeId];
    if (!node) {
      this._renderMissing(nodeId);
      return;
    }
    this.current = nodeId;
    // 进入节点即结算节点级道具进出
    this._applyItems(node.gain_items, node.consume_items, null);
    this._renderStage(node);
    this._renderHud();
    this._renderBottom(node);
  };

  Player.prototype._renderStage = function (node) {
    const src = node.media_url ? this.assetBase + node.media_url : null;
    if (src && node.media_type === "video") {
      this.$stage.innerHTML =
        `<video src="${esc(src)}" autoplay loop muted playsinline></video>`;
    } else if (src) {
      this.$stage.innerHTML = `<img src="${esc(src)}" alt="">`;
    } else {
      this.$stage.innerHTML = this._placeholder(node);
    }
  };

  // 无素材时的程序化占位底图（按情绪 / 场景生成配色与 emoji）
  Player.prototype._placeholder = function (node) {
    const e = node.emotion_intensity || 0.5;
    const hue1 = Math.round(260 - e * 220);
    const hue2 = Math.round(320 - e * 260);
    const emoji =
      node.type === "ending" ? "🎬" :
      node.type === "minigame" ? "⚡" :
      e > 0.75 ? "🔥" : e > 0.5 ? "✨" : e > 0.3 ? "🌙" : "🕊️";
    const scene = esc(node.location || (node.scene_id || "场景"));
    const tag = node.media_type === "video" ? "动态演出" : "静态画面";
    const bg = `linear-gradient(150deg, hsl(${hue1} 60% 32%), hsl(${hue2} 55% 20%))`;
    return `<div class="mh-placeholder" style="background:${bg}">
        <div class="mh-emoji">${emoji}</div>
        <div class="mh-ph-scene">${scene}</div>
        <div class="mh-ph-tag">${tag}</div>
      </div>`;
  };

  Player.prototype._renderHud = function () {
    const v = this.state.variables;
    let html = Object.keys(v)
      .map((k) => `<span class="mh-chip">${esc(k)} <b>${v[k]}</b></span>`)
      .join("");
    const inv = this.state.inventory;
    Object.keys(inv).forEach((id) => {
      const it = this.itemMap[id];
      html += `<span class="mh-chip mh-item">🎒 ${esc(it ? it.name : id)}${inv[id] > 1 ? " <b>×" + inv[id] + "</b>" : ""}</span>`;
    });
    this.$hud.innerHTML = html;
  };

  Player.prototype._renderBottom = function (node) {
    // 结局节点
    if (node.type === "ending") {
      this._renderEnding(node);
      return;
    }
    let html = "";
    if (node.character) html += `<div class="mh-speaker">${esc(node.character)}</div>`;
    const cls =
      node.type === "inner_monologue" ? " mh-inner" :
      node.type === "system" ? " mh-system" :
      node.type === "status_change" ? " mh-status" : "";
    html += `<div class="mh-textbox${cls}">${esc(node.content || "")}</div>`;
    this.$bottom.innerHTML = html;

    if (node.minigame) {
      this._renderMinigame(node);
    } else if (node.choices && node.choices.length) {
      this._renderChoices(node);
    } else {
      this._renderContinue(node);
    }
  };

  Player.prototype._renderChoices = function (node) {
    const wrap = document.createElement("div");
    wrap.className = "mh-choices";
    const self = this;
    node.choices.forEach((c, idx) => {
      const btn = document.createElement("button");
      btn.className = "mh-choice";
      const condOk = evalCond(c.requires, self.state);
      const itemsOk = (c.requires_items || []).every(
        (id) => (self.state.inventory[id] || 0) > 0
      );
      const ok = condOk && itemsOk;
      let extra = "";
      if (c.effects && Object.keys(c.effects).length) {
        extra += `<span class="mh-eff">${Object.keys(c.effects)
          .map((k) => k + (c.effects[k] >= 0 ? "+" : "") + c.effects[k])
          .join(" ")}</span>`;
      }
      if (!ok) {
        const reason = !itemsOk ? "缺道具" : renderCond(c.requires) || "未满足条件";
        extra += `<span class="mh-lock">🔒 ${esc(reason)}</span>`;
      }
      btn.innerHTML = esc(c.text) + extra;
      btn.disabled = !ok;
      btn.onclick = function () {
        self.state.taken.add(node.id + "#" + idx);
        self._applyItems(c.gain_items, c.consume_items, c.effects);
        self.show(c.goto);
      };
      wrap.appendChild(btn);
    });
    this.$bottom.appendChild(wrap);
  };

  Player.prototype._renderContinue = function (node) {
    // 无选项、非结局：顺延到下一节点（按 nodes 顺序）
    const idx = this.nodeOrder.indexOf(node.id);
    const nextId = idx >= 0 && idx + 1 < this.nodeOrder.length ? this.nodeOrder[idx + 1] : null;
    const self = this;
    const btn = document.createElement("button");
    btn.className = "mh-continue";
    if (nextId) {
      btn.textContent = "继续 ▶";
      btn.onclick = function () { self.show(nextId); };
    } else {
      btn.textContent = "▶ 完 · 重玩";
      btn.onclick = function () { self.reset(); };
    }
    this.$bottom.appendChild(btn);
  };

  Player.prototype._renderMinigame = function (node) {
    const mg = node.minigame;
    const self = this;
    const wrap = document.createElement("div");
    wrap.className = "mh-minigame";
    const label = { timed_click: "限时点击", qte: "QTE 快速反应", puzzle: "解谜" }[mg.type] || "小游戏";
    wrap.innerHTML =
      `<div class="mh-mg-hint">${label} · ${esc(mg.difficulty || "normal")} · 窗口 ${mg.window_ms}ms</div>
       <div class="mh-mg-bar"><div class="mh-mg-fill" data-mh="fill"></div></div>`;
    const btn = document.createElement("button");
    btn.className = "mh-mg-btn";
    btn.textContent = "⚡ 立即点击！";
    wrap.appendChild(btn);
    this.$bottom.appendChild(wrap);

    const fill = wrap.querySelector('[data-mh="fill"]');
    let done = false;
    const t0 = Date.now();
    const win = mg.window_ms || 800;
    // 倒计时进度条
    const timer = setInterval(function () {
      const left = Math.max(0, win - (Date.now() - t0));
      fill.style.width = (left / win) * 100 + "%";
      if (left <= 0 && !done) {
        done = true;
        clearInterval(timer);
        self.toast("挑战失败…");
        self.show(mg.on_failure || mg.on_success);
      }
    }, 30);
    btn.onclick = function () {
      if (done) return;
      done = true;
      clearInterval(timer);
      if (mg.reward) self._applyItems(null, null, mg.reward);
      self.toast("挑战成功！");
      self.show(mg.on_success);
    };
  };

  Player.prototype._matchEnding = function (node) {
    // 优先按 branch_id 匹配 endings；再按 unlock 条件筛可解锁的
    const byBranch = this.endings.filter((e) => e.branch_id && e.branch_id === node.branch_id);
    const pool = byBranch.length ? byBranch : this.endings;
    const unlocked = pool.filter((e) => evalCond(e.unlock, this.state));
    const trueEnd = unlocked.find((e) => e.is_true_ending);
    return trueEnd || unlocked[0] || pool[0] || null;
  };

  Player.prototype._renderEnding = function (node) {
    const ending = this._matchEnding(node);
    const self = this;
    const isTrue = ending && ending.is_true_ending;
    const div = document.createElement("div");
    div.className = "mh-ending" + (isTrue ? " mh-true" : "");
    div.innerHTML = `
      <div class="mh-ending-badge">${isTrue ? "★ TRUE ENDING ★" : "— 结局 —"}</div>
      <h2>${esc(ending ? ending.title : "尾声")}</h2>
      <div class="mh-ending-desc">${esc(node.content || "")}</div>
      <button class="mh-continue" data-mh="again">↺ 再玩一次</button>
    `;
    this.$stage.innerHTML = this._placeholder(node);
    this.$bottom.innerHTML = "";
    this.el.appendChild(div);
    this._endingEl = div;
    div.querySelector('[data-mh="again"]').onclick = function () {
      div.remove();
      self.reset();
    };
  };

  Player.prototype._renderMissing = function (id) {
    this.$bottom.innerHTML =
      `<div class="mh-textbox">⚠️ 节点缺失：${esc(id)}</div>`;
    const self = this;
    const btn = document.createElement("button");
    btn.className = "mh-continue";
    btn.textContent = "↺ 重玩";
    btn.onclick = function () { self.reset(); };
    this.$bottom.appendChild(btn);
  };

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // ------------------------- 对外 API ------------------------- //
  const ManhuaPlayer = {
    mount: function (container, game, opts) {
      if (typeof container === "string") container = document.querySelector(container);
      return new Player(container, game, opts);
    },
  };

  global.ManhuaPlayer = ManhuaPlayer;
  if (typeof module !== "undefined" && module.exports) module.exports = ManhuaPlayer;
})(typeof window !== "undefined" ? window : this);
