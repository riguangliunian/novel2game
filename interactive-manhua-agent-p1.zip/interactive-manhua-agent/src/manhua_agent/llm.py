"""LLM 路由层：按 Agent 的能力需求分发到不同端点。

设计遵循产品文档第 7 章 "按环节的能力需求分配模型" 的原则：
    - Parser: 长上下文（Gemini/GPT-4o）
    - Writer: 创意写作（Claude）
    - Others: 主 LLM

统一通过 OpenAI-Compatible SDK 调用，切换服务商 = 改 base_url。
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Literal, Optional, Type, TypeVar

from pydantic import BaseModel, ValidationError
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from .config import LLMEndpoint, Settings, get_settings

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

AgentRole = Literal[
    "parser", "planner", "writer", "consistency", "gamification", "direction", "structurer"
]


class LLMUnavailable(RuntimeError):
    """当没有配置 API Key、但业务代码想调用 LLM 时抛出。"""


class LLMRouter:
    """把 Agent 角色 → LLMEndpoint & 温度 的映射封装起来。

    使用 openai SDK 与任意 OpenAI-Compatible 端点交互。
    未安装 openai 或未配置 API Key 时，chat() 会抛 LLMUnavailable，
    由上层选择 fallback 到 dry-run。
    """

    def __init__(self, settings: Optional[Settings] = None) -> None:
        self.settings = settings or get_settings()

    # ------------------------------------------------------------------ #
    # 角色 → 端点/温度 映射
    # ------------------------------------------------------------------ #

    def endpoint_for(self, role: AgentRole) -> LLMEndpoint:
        s = self.settings
        mapping: Dict[str, LLMEndpoint] = {
            "parser": s.parser,
            "writer": s.writer,
        }
        return mapping.get(role, s.llm)

    def temperature_for(self, role: AgentRole) -> float:
        s = self.settings
        if role == "writer":
            return s.temperature_creative
        if role in ("planner", "consistency", "structurer"):
            return s.temperature_structure
        if role == "direction":
            return s.temperature_direction
        # parser/gamification 用默认
        return 0.5

    # ------------------------------------------------------------------ #
    # 主入口：chat & chat_json
    # ------------------------------------------------------------------ #

    def chat(
        self,
        role: AgentRole,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        response_format: Optional[Dict[str, Any]] = None,
    ) -> str:
        """普通聊天调用，返回字符串。"""
        endpoint = self.endpoint_for(role)
        if not endpoint.is_ready():
            raise LLMUnavailable(f"没有为 role={role} 配置 API Key（endpoint={endpoint.model}）")

        client = self._get_client(endpoint)
        kwargs: Dict[str, Any] = {
            "model": endpoint.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.temperature_for(role),
        }
        if response_format:
            kwargs["response_format"] = response_format

        return self._call_with_retry(client, kwargs)

    def chat_json(
        self,
        role: AgentRole,
        messages: List[Dict[str, str]],
        schema: Type[T],
        temperature: Optional[float] = None,
    ) -> T:
        """强制 JSON 输出并校验成 Pydantic Schema。

        遵循文档第 7 章：结构化输出用 JSON mode + schema 遵从度高的模型。
        失败会由 tenacity 重试 max_retry 次。
        """
        # 在 messages 里补一段 schema 说明，帮助模型自我约束
        schema_json = json.dumps(schema.model_json_schema(), ensure_ascii=False, indent=2)
        augmented = list(messages) + [
            {
                "role": "system",
                "content": (
                    "严格按照以下 JSON Schema 返回，不要输出任何多余文字，也不要用 ```json 包裹：\n"
                    f"{schema_json}"
                ),
            }
        ]

        @retry(
            reraise=True,
            stop=stop_after_attempt(self.settings.max_retry),
            wait=wait_exponential(multiplier=1, min=1, max=8),
            retry=retry_if_exception_type((json.JSONDecodeError, ValidationError)),
        )
        def _do() -> T:
            raw = self.chat(
                role=role,
                messages=augmented,
                temperature=temperature if temperature is not None else self.settings.temperature_structure,
                response_format={"type": "json_object"},
            )
            data = _extract_json(raw)
            return schema.model_validate(data)

        return _do()

    def embed(self, texts: List[str]) -> List[List[float]]:
        """嵌入接口——支线去重和长程记忆共用。"""
        endpoint = self.settings.embedding
        if not endpoint.is_ready():
            raise LLMUnavailable("没有配置嵌入模型 API Key")
        client = self._get_client(endpoint)
        resp = client.embeddings.create(model=endpoint.model, input=texts)
        return [item.embedding for item in resp.data]

    # ------------------------------------------------------------------ #
    # 内部：延迟构造 openai client（避免未装依赖时导入报错）
    # ------------------------------------------------------------------ #

    _client_cache: Dict[str, Any] = {}

    def _get_client(self, endpoint: LLMEndpoint) -> Any:
        cache_key = f"{endpoint.base_url}::{endpoint.api_key}"
        if cache_key in self._client_cache:
            return self._client_cache[cache_key]
        try:
            from openai import OpenAI  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise LLMUnavailable("请先安装 openai：pip install openai") from exc
        client = OpenAI(api_key=endpoint.api_key, base_url=endpoint.base_url)
        self._client_cache[cache_key] = client
        return client

    def _call_with_retry(self, client: Any, kwargs: Dict[str, Any]) -> str:
        @retry(
            reraise=True,
            stop=stop_after_attempt(self.settings.max_retry),
            wait=wait_exponential(multiplier=1, min=1, max=6),
        )
        def _do() -> str:
            resp = client.chat.completions.create(**kwargs)
            content = resp.choices[0].message.content
            if content is None:
                raise RuntimeError("LLM 返回空内容")
            return content

        return _do()


# --------------------------------------------------------------------------- #
# JSON 抽取：兼容偶尔用 ```json 包裹或前后有解释性文字的情况
# --------------------------------------------------------------------------- #


def _extract_json(text: str) -> Any:
    text = text.strip()
    if text.startswith("```"):
        # 去掉 ```json ... ``` 包裹
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:].lstrip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # 尝试从第一个 { 到最后一个 } 截取
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start : end + 1])
        raise
