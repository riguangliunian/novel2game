"""P1 素材生成子包：动静混合决策 + OpenAI-Compatible 图片 / 视频生成。"""

from .generator import (
    AssetResult,
    decide_media_types,
    generate_assets,
)

__all__ = ["AssetResult", "decide_media_types", "generate_assets"]
