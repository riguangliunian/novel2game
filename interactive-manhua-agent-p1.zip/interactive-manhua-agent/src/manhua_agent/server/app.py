"""P1：本地 FastAPI 服务 —— 封装 LangGraph 流水线为本地 API + 托管前端向导。

启动::

    manhua-agent-web                 # 控制台脚本
    python -m manhua_agent.server    # 或模块方式
    # 然后浏览器打开 http://127.0.0.1:8000

路由总览：
    GET  /                         向导前端页面
    GET  /player/*                 播放器引擎静态资源（预览用）
    GET  /api/config               默认配置（video_ratio / 素材 API 是否就绪）
    POST /api/jobs                 创建任务（自动跑到 Planner 后暂停）
    GET  /api/jobs/{id}/status     轮询进度
    GET  /api/jobs/{id}/skeleton   取 Planner 产出的分支结构（供审阅 / 编辑）
    POST /api/jobs/{id}/confirm    确认（可带编辑后的分支结构）→ 继续跑后续 Agent
    GET  /api/jobs/{id}/game       取最终 GameOutput（预览用）
    GET  /api/jobs/{id}/assets/*   素材静态服务（预览用）
    POST /api/jobs/{id}/export     打包导出 zip
    GET  /api/jobs/{id}/download   下载导出的 zip
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from ..config import PipelineConfig, get_settings
from ..models import StorySkeleton
from ..player import player_dir
from .jobs import JobManager

logger = logging.getLogger(__name__)

# 前端目录：<repo>/web
_WEB_DIR = Path(__file__).resolve().parents[3] / "web"


# --------------------------- 请求体 --------------------------- #
class CreateJobRequest(BaseModel):
    mode: str  # "novel" | "keywords"
    keywords: List[str] = []
    novel_text: Optional[str] = None
    theme: Optional[str] = None
    title: Optional[str] = None
    branch_count: int = 3
    staging: str = "semi-dynamic"
    max_nodes_per_branch: int = 6
    video_ratio: Optional[float] = None
    dry_run: bool = False


class ConfirmRequest(BaseModel):
    skeleton: Optional[Dict[str, Any]] = None  # 编辑后的分支结构（可选）


def create_app() -> FastAPI:
    app = FastAPI(title="互动漫剧生成器 · 本地向导", version="1.0.0")
    manager = JobManager()

    # ----------------------- 配置 ----------------------- #
    @app.get("/api/config")
    def api_config() -> Dict[str, Any]:
        s = get_settings()
        return {
            "video_ratio": s.video_ratio,
            "image_api_ready": s.image.is_ready(),
            "video_api_ready": s.video.is_ready(),
            "llm_ready": s.llm.is_ready(),
            "staging_options": ["static", "semi-dynamic", "full-video"],
        }

    # ----------------------- 创建任务 ----------------------- #
    @app.post("/api/jobs")
    def create_job(req: CreateJobRequest) -> Dict[str, Any]:
        try:
            config = PipelineConfig(
                mode=req.mode,  # type: ignore[arg-type]
                novel_text=req.novel_text,
                keywords=req.keywords,
                theme=req.theme,
                title=req.title,
                branch_count=req.branch_count,
                staging=req.staging,  # type: ignore[arg-type]
                max_nodes_per_branch=req.max_nodes_per_branch,
                video_ratio=req.video_ratio,
                dry_run=req.dry_run,
            )
            config.validate_mode()
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"参数错误：{exc}")
        job = manager.create(config)
        return {"job_id": job.id, "status": job.status}

    # ----------------------- 进度 ----------------------- #
    @app.get("/api/jobs/{job_id}/status")
    def job_status(job_id: str) -> Dict[str, Any]:
        job = manager.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="任务不存在")
        return manager.status_dict(job)

    # ----------------------- 分支结构（HITL） ----------------------- #
    @app.get("/api/jobs/{job_id}/skeleton")
    def get_skeleton(job_id: str) -> Dict[str, Any]:
        job = manager.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="任务不存在")
        if job.skeleton is None:
            raise HTTPException(status_code=409, detail="Planner 尚未完成")
        return job.skeleton.model_dump()

    @app.post("/api/jobs/{job_id}/confirm")
    def confirm(job_id: str, req: ConfirmRequest) -> Dict[str, Any]:
        job = manager.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="任务不存在")
        edited: Optional[StorySkeleton] = None
        if req.skeleton is not None:
            try:
                edited = StorySkeleton.model_validate(req.skeleton)
            except Exception as exc:
                raise HTTPException(status_code=400, detail=f"分支结构不合法：{exc}")
        try:
            manager.confirm(job, edited)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc))
        return {"job_id": job.id, "status": job.status}

    # ----------------------- 最终产物 ----------------------- #
    @app.get("/api/jobs/{job_id}/game")
    def get_game(job_id: str) -> JSONResponse:
        job = manager.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="任务不存在")
        if job.game is None:
            raise HTTPException(status_code=409, detail="任务尚未完成")
        return JSONResponse(content=job.game.model_dump())

    @app.get("/api/jobs/{job_id}/assets/{filename}")
    def get_asset(job_id: str, filename: str) -> FileResponse:
        job = manager.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="任务不存在")
        # 防目录穿越
        fpath = (job.assets_dir / Path(filename).name).resolve()
        if not str(fpath).startswith(str(job.assets_dir.resolve())) or not fpath.exists():
            raise HTTPException(status_code=404, detail="素材不存在")
        return FileResponse(fpath)

    # ----------------------- 导出 ----------------------- #
    @app.post("/api/jobs/{job_id}/export")
    def export(job_id: str) -> Dict[str, Any]:
        job = manager.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="任务不存在")
        try:
            result = manager.export(job)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc))
        return result.as_dict()

    @app.get("/api/jobs/{job_id}/download")
    def download(job_id: str) -> FileResponse:
        job = manager.get(job_id)
        if not job or not job.zip_path.exists():
            raise HTTPException(status_code=404, detail="导出包不存在，请先导出")
        safe_title = (job.game.title if job.game else "game") or "game"
        return FileResponse(
            job.zip_path,
            media_type="application/zip",
            filename=f"{safe_title}.zip",
        )

    # ----------------------- 静态资源 ----------------------- #
    # 播放器引擎（预览时前端会加载 /player/player.js、/player/player.css）
    app.mount("/player", StaticFiles(directory=str(player_dir())), name="player")

    @app.get("/", response_class=HTMLResponse)
    def index() -> HTMLResponse:
        idx = _WEB_DIR / "index.html"
        if not idx.exists():
            return HTMLResponse("<h1>前端未找到</h1><p>缺少 web/index.html</p>", status_code=500)
        return HTMLResponse(idx.read_text(encoding="utf-8"))

    # 其余前端静态文件（app.js / style.css）
    if _WEB_DIR.exists():
        app.mount("/web", StaticFiles(directory=str(_WEB_DIR)), name="web")

    return app


def main() -> None:
    import argparse

    import uvicorn

    parser = argparse.ArgumentParser(
        prog="manhua-agent-web",
        description="启动互动漫剧生成器的本地 Web 向导服务",
    )
    parser.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    parser.add_argument("--port", type=int, default=8000, help="端口（默认 8000）")
    parser.add_argument("--reload", action="store_true", help="开发模式热重载")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s | %(message)s")
    print(f"\n  互动漫剧生成器 · 本地向导已启动 → http://{args.host}:{args.port}\n")
    if args.reload:
        uvicorn.run("manhua_agent.server.app:create_app", host=args.host, port=args.port,
                    reload=True, factory=True)
    else:
        uvicorn.run(create_app(), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
