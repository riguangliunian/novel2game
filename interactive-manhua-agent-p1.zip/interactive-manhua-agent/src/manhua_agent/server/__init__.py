"""P1 Web 服务子包：FastAPI 应用 + 任务管理。"""

from .app import create_app, main

__all__ = ["create_app", "main"]
