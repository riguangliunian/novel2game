"""互动漫剧游戏生成智能体 (Interactive Manhua Game Agent).

一条「输入 → 多 Agent 串行流水线 → 结构化 JSON」的生成链路。

Public API:
    - PipelineConfig: 生成任务的配置
    - PipelineResult: 生成结果（含 story_tree/variables/assets）
    - run_pipeline: 顶层入口

参考产品设计文档 v1.0（陆子桐, 2026-07-20）。
"""

from .config import PipelineConfig, Settings, get_settings
from .models import (
    Choice,
    Ending,
    GameOutput,
    Minigame,
    PipelineResult,
    Node,
    StoryTree,
)
from .graph import run_pipeline

__all__ = [
    "PipelineConfig",
    "PipelineResult",
    "GameOutput",
    "StoryTree",
    "Node",
    "Choice",
    "Ending",
    "Minigame",
    "Settings",
    "get_settings",
    "run_pipeline",
]

__version__ = "1.2.0"
