"""LangGraph 流水线编排。

把 7 个 Agent 串成一条有向图：
    parse → plan → write → check → gamify → direct → structure

一致性校验 (check) 若发现分支雷同或人设冲突，会条件回边到 write 重写；
超过 max_retry 后放行到 gamify（并把 issues 记入 metadata 供上游发现）。

v1.2：
- gamification 现在返回 (nodes, endings, items)
- direction 现在返回 (nodes, scenes, bgms, cgs, voiceovers)
- structurer 汇总所有 v1.2 资产
- check 阶段追加纯规则的 v1.2 结构性一致性检查

如果未安装 langgraph，会自动 fallback 到简易 sequential runner。
"""

from __future__ import annotations

import logging
from typing import Any, List, Optional, TypedDict

from .config import PipelineConfig
from .llm import LLMRouter, LLMUnavailable
from .models import (
    BGM,
    CG,
    ConsistencyReport,
    Ending,
    GameOutput,
    Item,
    Node,
    PipelineResult,
    Scene,
    StorySetting,
    StorySkeleton,
    Voiceover,
)
from .agents import (
    mock_consistency,
    mock_direction,
    mock_gamification,
    mock_parser,
    mock_planner,
    mock_structurer,
    mock_writer,
    run_consistency,
    run_direction,
    run_gamification,
    run_parser,
    run_planner,
    run_structurer,
    run_writer,
)
from .agents.consistency import check_v12_structure

logger = logging.getLogger(__name__)


class _State(TypedDict, total=False):
    config: PipelineConfig
    router: Optional[LLMRouter]
    logs: List[str]
    setting: StorySetting
    skeleton: StorySkeleton
    nodes: List[Node]
    endings: List[Ending]
    items: List[Item]
    scenes: List[Scene]
    bgms: List[BGM]
    cgs: List[CG]
    voiceovers: List[Voiceover]
    consistency: ConsistencyReport
    game: GameOutput
    retry_count: int


# --------------------------------------------------------------------------- #
# 节点函数
# --------------------------------------------------------------------------- #


def _log(state: _State, msg: str) -> None:
    state.setdefault("logs", []).append(msg)
    if state["config"].verbose:
        logger.info(msg)
        print(f"[pipeline] {msg}")


def _call(fn_llm, fn_mock, config: PipelineConfig, router: Optional[LLMRouter], *args):
    """LLM-可用 → 真实调用；否则 → mock。任何 LLMUnavailable 都自动降级到 mock。"""
    if config.dry_run or router is None:
        return fn_mock(config, *args)
    try:
        return fn_llm(config, *args, router)
    except LLMUnavailable as exc:
        logger.warning("LLM unavailable, falling back to mock: %s", exc)
        return fn_mock(config, *args)


def node_parse(state: _State) -> _State:
    setting = _call(run_parser, lambda cfg: mock_parser(cfg), state["config"], state.get("router"))
    _log(state, f"parser: 生成设定《{setting.title}》，角色 {len(setting.characters)} 个")
    return {**state, "setting": setting}


def node_plan(state: _State) -> _State:
    skeleton = _call(
        lambda cfg, setting, router: run_planner(cfg, setting, router),
        lambda cfg, setting: mock_planner(cfg, setting),
        state["config"], state.get("router"), state["setting"],
    )
    act_cnt = len(skeleton.acts) if skeleton.acts else 0
    chap_cnt = len(skeleton.chapters) if skeleton.chapters else 0
    _log(
        state,
        f"planner: {len(skeleton.branches)} 条分支，变量 {list(skeleton.variables.keys())}，"
        f"幕 {act_cnt} / 章 {chap_cnt}",
    )
    return {**state, "skeleton": skeleton}


def node_write(state: _State) -> _State:
    nodes = _call(
        lambda cfg, setting, skel, router: run_writer(cfg, setting, skel, router),
        lambda cfg, setting, skel: mock_writer(cfg, setting, skel),
        state["config"], state.get("router"), state["setting"], state["skeleton"],
    )
    _log(state, f"writer: 生成节点 {len(nodes)} 条")
    return {**state, "nodes": nodes}


def node_check(state: _State) -> _State:
    report = _call(
        lambda cfg, setting, skel, nodes, router: run_consistency(cfg, setting, skel, nodes, router),
        lambda cfg, setting, skel, nodes: mock_consistency(cfg, setting, skel, nodes),
        state["config"], state.get("router"),
        state["setting"], state["skeleton"], state["nodes"],
    )
    _log(
        state,
        f"consistency: passed={report.passed}, dup_pairs={report.duplicate_branch_pairs}, "
        f"issues={len(report.issues)}",
    )
    return {**state, "consistency": report}


def node_gamify(state: _State) -> _State:
    result = _call(
        lambda cfg, setting, skel, nodes, router: run_gamification(cfg, setting, skel, nodes, router),
        lambda cfg, setting, skel, nodes: mock_gamification(cfg, setting, skel, nodes),
        state["config"], state.get("router"),
        state["setting"], state["skeleton"], state["nodes"],
    )
    nodes, endings, items = result
    _log(
        state,
        f"gamification: 挂 choices/minigame，结局 {len(endings)} 个，道具 {len(items)} 件",
    )
    return {**state, "nodes": nodes, "endings": endings, "items": items}


def node_direct(state: _State) -> _State:
    result = _call(
        lambda cfg, setting, nodes, router: run_direction(cfg, setting, nodes, router),
        lambda cfg, setting, nodes: mock_direction(cfg, setting, nodes),
        state["config"], state.get("router"),
        state["setting"], state["nodes"],
    )
    nodes, scenes, bgms, cgs, voiceovers = result
    tier_stats: dict[str, int] = {}
    for n in nodes:
        tier_stats[n.staging] = tier_stats.get(n.staging, 0) + 1
    _log(
        state,
        f"direction: 演出档位分布 {tier_stats}，场景 {len(scenes)} / BGM {len(bgms)} / CG {len(cgs)} / VO {len(voiceovers)}",
    )
    return {
        **state,
        "nodes": nodes,
        "scenes": scenes,
        "bgms": bgms,
        "cgs": cgs,
        "voiceovers": voiceovers,
    }


def node_structure(state: _State) -> _State:
    # 结构化输出本身就是规则合并 + 自修复，无 LLM 分支
    game = mock_structurer(
        state["config"],
        state["setting"],
        state["skeleton"],
        state["nodes"],
        state["endings"],
        items=state.get("items", []),
        scenes=state.get("scenes", []),
        bgms=state.get("bgms", []),
        cgs=state.get("cgs", []),
        voiceovers=state.get("voiceovers", []),
    )
    # v1.2：结构化后再补一次 v1.2 结构性一致性检查（纯规则）
    check_v12_structure(
        game.story_tree.nodes,
        game.story_tree.endings,
        set(game.variables.keys()),
        {it.id for it in game.assets.items},
        state["consistency"],
    )
    game.metadata["consistency"] = state["consistency"].model_dump()
    _log(state, f"structurer: 输出 GameOutput，start={game.story_tree.start_node}")
    return {**state, "game": game}


# --------------------------------------------------------------------------- #
# 条件回边：check 未通过时重写一次
# --------------------------------------------------------------------------- #


def _should_rewrite(state: _State) -> str:
    """检查 consistency 是否通过；未通过且重试次数未超限 → 回 write。"""
    max_retry = state["config"].branch_count  # 允许每条分支重试一次
    retry = state.get("retry_count", 0)
    if state["consistency"].passed:
        return "ok"
    if retry >= max_retry:
        _log(state, f"consistency: 已重试 {retry} 次，放行到 gamification")
        return "ok"
    _log(state, f"consistency: 触发重写（第 {retry + 1} 次）")
    return "rewrite"


def node_rewrite_bump(state: _State) -> _State:
    return {**state, "retry_count": state.get("retry_count", 0) + 1}


# --------------------------------------------------------------------------- #
# 图构造：优先 LangGraph；未安装时 fallback
# --------------------------------------------------------------------------- #


def _build_graph() -> Any:
    """构造 LangGraph StateGraph；未安装 langgraph 时返回 None。"""
    try:
        from langgraph.graph import END, StateGraph  # type: ignore
    except ImportError:
        return None

    g: Any = StateGraph(_State)
    g.add_node("parse", node_parse)
    g.add_node("plan", node_plan)
    g.add_node("write", node_write)
    g.add_node("check", node_check)
    g.add_node("rewrite_bump", node_rewrite_bump)
    g.add_node("gamify", node_gamify)
    g.add_node("direct", node_direct)
    g.add_node("structure", node_structure)

    g.set_entry_point("parse")
    g.add_edge("parse", "plan")
    g.add_edge("plan", "write")
    g.add_edge("write", "check")
    g.add_conditional_edges(
        "check",
        _should_rewrite,
        {"ok": "gamify", "rewrite": "rewrite_bump"},
    )
    g.add_edge("rewrite_bump", "write")
    g.add_edge("gamify", "direct")
    g.add_edge("direct", "structure")
    g.add_edge("structure", END)
    return g.compile()


def _run_sequential(state: _State) -> _State:
    """未安装 langgraph 时的 fallback runner，语义与图版本一致。"""
    state = node_parse(state)
    state = node_plan(state)
    for attempt in range(state["config"].branch_count + 1):
        state = node_write(state)
        state = node_check(state)
        if state["consistency"].passed:
            break
        state = node_rewrite_bump(state)
    state = node_gamify(state)
    state = node_direct(state)
    state = node_structure(state)
    return state


# --------------------------------------------------------------------------- #
# 顶层入口
# --------------------------------------------------------------------------- #


def run_pipeline(config: PipelineConfig) -> PipelineResult:
    config.validate_mode()
    router: Optional[LLMRouter] = None
    if not config.dry_run:
        try:
            router = LLMRouter()
        except Exception as exc:  # pragma: no cover
            logger.warning("无法初始化 LLMRouter，将走 dry-run：%s", exc)

    state: _State = {"config": config, "router": router, "logs": [], "retry_count": 0}

    graph = _build_graph()
    if graph is None:
        final_state = _run_sequential(state)
    else:
        final_state = graph.invoke(state)  # type: ignore[arg-type]

    return PipelineResult(
        game=final_state["game"],
        setting=final_state["setting"],
        skeleton=final_state["skeleton"],
        consistency=final_state["consistency"],
        agent_logs=final_state.get("logs", []),
    )
