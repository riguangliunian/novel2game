"""全局配置：环境变量 + 单次运行 PipelineConfig。

环境变量分层：
    - LLM_*             主 LLM
    - PARSER_*          解析 Agent 专用（长上下文）
    - WRITER_*          写作 Agent 专用（创意写作）
    - EMBEDDING_*       嵌入模型（去重）

未指定专用模型时，自动 fallback 到主 LLM。
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import List, Literal, Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field

load_dotenv()  # 幂等：多次调用只会加载一次


class LLMEndpoint(BaseModel):
    """一个 OpenAI-Compatible 端点的完整参数集合。"""

    api_key: Optional[str] = None
    base_url: Optional[str] = None
    model: str = "gpt-4o-mini"
    temperature: float = 0.7

    def is_ready(self) -> bool:
        """判断该端点是否有可用的 API Key。"""
        return bool(self.api_key)


class AssetEndpoint(BaseModel):
    """素材生成端点（OpenAI-Compatible 的图像 / 视频生成服务）。

    P1 新增：图片生成 API 和视频生成 API 各保留一个「填写入口」。
    ``is_ready()`` 用来判断是否启用——填了 api_key 就启用，没填就跳过素材生成。
    """

    api_key: Optional[str] = None
    base_url: Optional[str] = None
    model: Optional[str] = None
    size: str = "512x512"

    def is_ready(self) -> bool:
        return bool(self.api_key and self.model)


class Settings(BaseModel):
    """全局设置，从 .env 加载。"""

    # 主 LLM
    llm: LLMEndpoint = Field(default_factory=LLMEndpoint)

    # 专用端点
    parser: LLMEndpoint = Field(default_factory=LLMEndpoint)
    writer: LLMEndpoint = Field(default_factory=LLMEndpoint)
    embedding: LLMEndpoint = Field(default_factory=lambda: LLMEndpoint(model="text-embedding-3-small"))

    # P1 新增：素材生成端点（图片 / 视频）
    image: AssetEndpoint = Field(default_factory=AssetEndpoint)
    video: AssetEndpoint = Field(default_factory=AssetEndpoint)

    # 温度分档
    temperature_creative: float = 0.9
    temperature_structure: float = 0.2
    temperature_direction: float = 0.5

    # 相似度阈值
    similarity_threshold: float = 0.85

    # 最大重试次数
    max_retry: int = 3

    # P1 新增：动静混合默认动态比例（约 20% 节点生成视频，其余静态图）
    video_ratio: float = 0.2


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """读取 .env 生成 Settings。缓存一次即可，测试可 clear cache 重载。"""

    def _endpoint(prefix: str, default_model: str) -> LLMEndpoint:
        return LLMEndpoint(
            api_key=os.getenv(f"{prefix}_API_KEY"),
            base_url=os.getenv(f"{prefix}_BASE_URL"),
            model=os.getenv(f"{prefix}_MODEL", default_model),
        )

    main = _endpoint("LLM", "gpt-4o-mini")

    parser = _endpoint("PARSER", main.model)
    # fallback：未单独配置则复用主 LLM
    if not parser.api_key:
        parser.api_key = main.api_key
        parser.base_url = parser.base_url or main.base_url

    writer = _endpoint("WRITER", main.model)
    if not writer.api_key:
        writer.api_key = main.api_key
        writer.base_url = writer.base_url or main.base_url

    embedding = _endpoint("EMBEDDING", "text-embedding-3-small")
    if not embedding.api_key:
        embedding.api_key = main.api_key
        embedding.base_url = embedding.base_url or main.base_url

    # P1：素材生成端点（图片 / 视频）。默认复用主 LLM 的 base_url，可单独覆盖。
    image = AssetEndpoint(
        api_key=os.getenv("IMAGE_API_KEY"),
        base_url=os.getenv("IMAGE_BASE_URL") or main.base_url,
        model=os.getenv("IMAGE_MODEL"),
        size=os.getenv("IMAGE_SIZE", "512x512"),
    )
    video = AssetEndpoint(
        api_key=os.getenv("VIDEO_API_KEY"),
        base_url=os.getenv("VIDEO_BASE_URL") or main.base_url,
        model=os.getenv("VIDEO_MODEL"),
        size=os.getenv("VIDEO_SIZE", "512x512"),
    )

    return Settings(
        llm=main,
        parser=parser,
        writer=writer,
        embedding=embedding,
        image=image,
        video=video,
        temperature_creative=float(os.getenv("TEMPERATURE_CREATIVE", "0.9")),
        temperature_structure=float(os.getenv("TEMPERATURE_STRUCTURE", "0.2")),
        temperature_direction=float(os.getenv("TEMPERATURE_DIRECTION", "0.5")),
        similarity_threshold=float(os.getenv("SIMILARITY_THRESHOLD", "0.85")),
        max_retry=int(os.getenv("MAX_RETRY", "3")),
        video_ratio=float(os.getenv("VIDEO_RATIO", "0.2")),
    )


StagingTier = Literal["static", "semi-dynamic", "full-video"]


class PipelineConfig(BaseModel):
    """一次生成任务的入参。"""

    mode: Literal["novel", "keywords"] = Field(
        ..., description="novel = 上传小说改编；keywords = 关键词原创"
    )

    # novel 模式
    novel_text: Optional[str] = Field(None, description="小说全文（novel 模式）")

    # keywords 模式
    keywords: List[str] = Field(default_factory=list, description="关键词列表（keywords 模式）")
    theme: Optional[str] = Field(None, description="主题/世界观说明（keywords 模式，可选）")

    # 通用参数
    title: Optional[str] = Field(None, description="作品标题；未给则由 AI 生成")
    branch_count: int = Field(3, ge=2, le=6, description="主分支数量（>=2）")
    staging: StagingTier = Field("semi-dynamic", description="演出档位（全静态/进阶动态/全视频）")
    max_nodes_per_branch: int = Field(6, ge=3, le=20, description="每条分支的节点数上限")

    # P1 新增：动静混合动态比例（视频节点占比）。None 时回落到全局 Settings.video_ratio。
    video_ratio: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="视频节点占比（动静混合），未指定则用全局默认 0.2"
    )

    # 运行选项
    dry_run: bool = Field(False, description="不调用 LLM，走内置占位规则生成器")
    verbose: bool = Field(False, description="打印每个 Agent 的中间产物")

    def validate_mode(self) -> None:
        if self.mode == "novel" and not self.novel_text:
            raise ValueError("novel 模式下必须提供 novel_text")
        if self.mode == "keywords" and not self.keywords and not self.theme:
            raise ValueError("keywords 模式下 keywords 与 theme 至少填一项")
