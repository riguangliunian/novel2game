"""Prompts sub-package. See system_prompts.py."""

from .system_prompts import (
    CONSISTENCY_SYSTEM,
    DIRECTION_SYSTEM,
    GAMIFICATION_SYSTEM,
    PARSER_SYSTEM,
    PLANNER_SYSTEM,
    STRUCTURER_SYSTEM,
    WRITER_SYSTEM,
)

__all__ = [
    "PARSER_SYSTEM",
    "PLANNER_SYSTEM",
    "WRITER_SYSTEM",
    "CONSISTENCY_SYSTEM",
    "GAMIFICATION_SYSTEM",
    "DIRECTION_SYSTEM",
    "STRUCTURER_SYSTEM",
]
